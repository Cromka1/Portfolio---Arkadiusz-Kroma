<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'sklepinternetowy');

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Błąd połączenia z bazą']));
}

if (!isset($_SESSION['id'])) {
    die(json_encode(['success' => false, 'message' => 'Użytkownik nie jest zalogowany']));
}

$id_uzytkownika = $_SESSION['id'];

// Pobierz wszystkie produkty z koszyka użytkownika
$sql = "SELECT id_produkt FROM koszyk WHERE id = '$id_uzytkownika'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Dla każdego produktu w koszyku twórz zamówienie
        $id_produktu = $row['id_produkt'];
        $sql_zamowienie = "INSERT INTO zamowienie (id_uzytkownika, id_produktu, datazamowienia) 
                          VALUES ('$id_uzytkownika', '$id_produktu', NOW())";
        
        $conn->query($sql_zamowienie);
    }
    
    // Wyczyść koszyk użytkownika
    $sql_clear = "DELETE FROM koszyk WHERE id = '$id_uzytkownika'";
    $conn->query($sql_clear);
    
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Koszyk jest pusty']);
}

$conn->close();
?>