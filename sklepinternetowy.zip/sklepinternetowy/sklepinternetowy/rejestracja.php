<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestracja</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #ffffff;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background: #000000;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 320px;
            border: 2px solid #DAA520;
        }

        h1 {
            font-family: 'Playfair Display', serif;
            color: #DAA520;
            margin-bottom: 30px;
            font-size: 32px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        input[type="text"] {
            width: 100%;
            padding: 14px;
            margin: 10px 0;
            border: 2px solid #DAA520;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            outline: none;
            background-color: #000000;
            color: #DAA520;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus {
            border-color: #ffffff;
            box-shadow: 0 0 10px rgba(218, 165, 32, 0.3);
        }

        input[type="text"]::placeholder {
            color: #DAA520;
            opacity: 0.7;
        }

        input[type="submit"] {
            width: 100%;
            padding: 14px;
            background-color: #DAA520;
            color: #000000;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            font-weight: 600;
            margin-top: 20px;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        input[type="submit"]:hover {
            background-color: #ffffff;
            color: #000000;
            box-shadow: 0 0 15px rgba(218, 165, 32, 0.5);
        }

        .login-link {
            background: none;
            border: 2px solid #DAA520;
            color: #DAA520;
            padding: 12px 24px;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .login-link:hover {
            background-color: #DAA520;
            color: #000000;
            box-shadow: 0 0 15px rgba(218, 165, 32, 0.3);
        }
    </style>
</head>
<body>
    <div class="container">
        <center>
            <h1>Rejestracja</h1>
            <form method="post">
                <input type="text" name="login" placeholder="Login:" required>
                <input type="text" name="haslo" placeholder="Hasło:" required>
                <input type="submit" value="Zarejestruj się">    
            </form>
            <br>
            <button class="login-link" onclick="window.location.href='usercheck.php'">
                Masz już konto? Zaloguj się!
            </button>
            <button class="login-link" onclick="window.location.href='guest_login.php'">
                Zaloguj się jako gość!
            </button>
        </center>
    </div>

    <?php
    if(isset($_POST['login']) && isset($_POST['haslo'])) {
        $con = mysqli_connect("localhost", "root", "", "sklepinternetowy");
        
        $login = $_POST["login"];
        $check_query = "SELECT * FROM user WHERE login = '$login'";
        $check_result = mysqli_query($con, $check_query);
        
        if(mysqli_num_rows($check_result) > 0) {
            echo "<script>alert('Ten login jest już zajęty. Wybierz inny login.');</script>";
        } else {
            $password = $_POST["haslo"];
            $query = "INSERT INTO `user`(`login`, `password`) VALUES ('$login','$password')";
            $result = mysqli_query($con, $query);
            
            if($result) {
                header("Location: usercheck.php");
            } else {
                echo "<script>alert('Wystąpił błąd podczas rejestracji.');</script>";
            }
        }
    }
    ?>
</body>
</html>