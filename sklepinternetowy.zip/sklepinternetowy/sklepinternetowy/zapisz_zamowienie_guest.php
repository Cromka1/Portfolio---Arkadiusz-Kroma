<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'sklepinternetowy');

$idGoscia = $_SESSION['id'];

// Pobierz produkty z koszyka gościa
$sql = "SELECT id_produkt FROM koszyk_goscia WHERE id_goscia = '$idGoscia'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $id_produktu = $row['id_produkt'];
        // Dodaj do zamówień gościa
        $sql_zamowienie = "INSERT INTO zamowienie_goscia (id_goscia, id_produkt, data_zamowienia) 
                          VALUES ('$idGoscia', '$id_produktu', NOW())";
        $conn->query($sql_zamowienie);
    }
    
    // Wyczyść koszyk gościa
    $sql_clear = "DELETE FROM koszyk_goscia WHERE id_goscia = '$idGoscia'";
    $conn->query($sql_clear);
    
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Koszyk jest pusty']);
}

$conn->close();
?>