<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #ffffff;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background: #000000;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 320px;
            border: 2px solid #DAA520;
        }

        h1 {
            font-family: 'Playfair Display', serif;
            color: #DAA520;
            margin-bottom: 30px;
            font-size: 32px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        input[type="text"] {
            width: 100%;
            padding: 14px;
            margin: 10px 0;
            border: 2px solid #DAA520;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            outline: none;
            background-color: #000000;
            color: #DAA520;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus {
            border-color: #ffffff;
            box-shadow: 0 0 10px rgba(218, 165, 32, 0.3);
        }

        input[type="text"]::placeholder {
            color: #DAA520;
            opacity: 0.7;
        }

        input[type="submit"] {
            width: 100%;
            padding: 14px;
            background-color: #DAA520;
            color: #000000;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            font-weight: 600;
            margin-top: 20px;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        input[type="submit"]:hover {
            background-color: #ffffff;
            color: #000000;
            box-shadow: 0 0 15px rgba(218, 165, 32, 0.5);
        }

        .register-link {
            background: none;
            border: 2px solid #DAA520;
            color: #DAA520;
            padding: 12px 24px;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .register-link:hover {
            background-color: #DAA520;
            color: #000000;
            box-shadow: 0 0 15px rgba(218, 165, 32, 0.3);
        }
    </style>
</head>
<body>
    <div class="container">
        <center>
            <h1>Logowanie</h1>
            <form method="post">
                <input type="text" name="login" placeholder="Login:" required>
                <input type="text" name="haslo" placeholder="Hasło:" required>
                <input type="submit" value="Zaloguj">
            </form>
            <br>
            <button class="register-link" onclick="window.location.href='rejestracja.php'">
                Utwórz nowe konto
            </button>
        </center>
    </div>

    <?php
function validate() {
    session_start();
    $con = mysqli_connect("localhost", "root", "", "sklepinternetowy");
    $login = $_POST["login"];
    $password = $_POST["haslo"];
    
    $query = "SELECT id, login, password FROM `user` WHERE login='$login' AND password='$password'";
    $wynik = mysqli_query($con, $query);
    
    if ($wynik && mysqli_num_rows($wynik) > 0) {
        $row = mysqli_fetch_assoc($wynik);
        $_SESSION["id"] = $row['id'];
        $_SESSION["user"] = $row['login'];
        $_SESSION["guest"] = false;  // Ważne: ustawiamy guest na false
        header("Location: glowna.php");
    } else {
        echo "<script> alert('Błędne dane logowania');</script>";
    }
}

if(!empty($_POST))
    validate();
?>
</body>
</html>