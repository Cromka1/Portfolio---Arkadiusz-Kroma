<?php
session_start();

if (!isset($_SESSION['guest']) || $_SESSION['guest'] !== true) {
    die(json_encode(['success' => false, 'message' => 'Brak dostępu']));
}

$conn = new mysqli('localhost', 'root', '', 'sklepinternetowy');

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Błąd połączenia z bazą']));
}

$idProduktu = isset($_POST['idProduktu']) ? (int)$_POST['idProduktu'] : 0;
$idGoscia = isset($_SESSION['id']) ? (int)$_SESSION['id'] : 0;

if ($idProduktu > 0 && $idGoscia > 0) {
    $sql = "INSERT INTO koszyk_goscia (id_goscia, id_produkt) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $idGoscia, $idProduktu);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Produkt dodany do koszyka']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Błąd podczas dodawania produktu']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Nieprawidłowe dane']);
}

$conn->close();
?>