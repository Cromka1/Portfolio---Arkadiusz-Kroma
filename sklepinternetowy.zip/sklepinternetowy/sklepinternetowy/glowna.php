<?php
session_start();
$isGuest = isset($_SESSION['guest']) && $_SESSION['guest'] === true;
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lego World</title>
    <style>
        /* General Reset and Base Styles */
/* General Reset and Base Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #fff;
    color: #333;
}

/* Header Section */
#gora {
    width: 100%;
    height: 200px;
    background-color: #000;
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
}

#gora h1 {
    font-size: 3rem;
    text-transform: uppercase;
    letter-spacing: 2px;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
}

#gora img {
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
    width: 50px;
    height: auto;
    cursor: pointer;
}

/* Hidden Basket (initially off-screen) */
#koszyk {
    position: fixed;
    top: 0;
    right: -300px;
    width: 300px;
    height: 100%;
    background-color: #fff;
    color: #000;
    box-shadow: -4px 0 10px rgba(0, 0, 0, 0.3);
    transition: right 0.3s ease-in-out;
    padding: 20px;
    z-index: 100;
}

#koszyk.active {
    right: 0;
}

/* Close button */
#closeKoszyk {
    position: absolute;
    top: 20px;
    right: 20px;
    font-size: 24px;
    cursor: pointer;
}

/* Basket content */
#koszyk ul {
    list-style-type: none;
    padding: 0;
}

#koszyk li {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

#koszykSuma {
    margin-top: 20px;
    padding: 15px;
    border-top: 2px solid #ddd;
    font-weight: bold;
    text-align: right;
    font-size: 1.2em;
}

/* Koszyk Lista (Scrollable) */
#koszykLista {
    max-height: calc(100vh - 250px);
    overflow-y: auto;
    margin: 20px 0;
    padding-right: 5px;
}

#koszykLista::-webkit-scrollbar {
    width: 5px;
}

#koszykLista::-webkit-scrollbar-track {
    background: #f1f1f1;
}

#koszykLista::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
}

/* Koszyk items */
.koszyk-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid #ddd;
    margin-bottom: 10px;
    background-color: #f9f9f9;
    border-radius: 5px;
}

.koszyk-item span {
    font-size: 14px;
}

.koszyk-item span:first-child {
    flex: 2;
    margin-right: 10px;
}

.koszyk-item span:nth-child(2) {
    flex: 1;
    text-align: right;
    margin-right: 10px;
    font-weight: bold;
}

.koszyk-item button {
    background-color: #ff4444;
    color: white;
    border: none;
    padding: 5px 10px;
    font-size: 12px;
    cursor: pointer;
    border-radius: 3px;
    transition: background-color 0.3s;
    width: auto;
    margin: 0;
}

.koszyk-item button:hover {
    background-color: #ff0000;
}

/* Main Products Layout */
.produkt {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #d4af37;
    margin: 20px auto;
    width: 75%;
    padding: 20px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.produkt:hover {
    transform: scale(1.03);
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
}

/* Image Styles */
.zdjecie {
    width: 35%;
    height: 250px;
    background-size: cover;
    background-position: center;
    border-radius: 10px;
    overflow: hidden;
}

#zdjecie1 { background-image: url("ferrari.jpg"); }
#zdjecie2 { background-image: url("lambo.jpg"); }
#zdjecie3 { background-image: url("mercedes.jpg"); }
#zdjecie4 { background-image: url("ford.jpg"); }
#zdjecie5 { background-image: url("bugatti.jpg"); }

.tekst {
    width: 55%;
    color: #000;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    align-items: center;
    padding-left: 20px;
}

.tekst div {
    margin-bottom: 15px;
    font-size: 1rem;
    line-height: 1.6;
    color: #333;
}

button {
    background-color: #000;
    color: #fff;
    border: none;
    padding: 12px 20px;
    font-size: 1rem;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s ease, transform 0.2s ease;
    width: 100%;
    margin-top: 15px;
}

button:hover {
    background-color: #b58a27;
    transform: translateY(-2px);
}

button:active {
    background-color: #8b6910;
    transform: translateY(0);
}

#koszyk button[onclick="przejdzDoPlatnosci()"] {
    width: 100%;
    margin-top: 20px;
    padding: 15px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

#koszyk button[onclick="przejdzDoPlatnosci()"]:hover {
    background-color: #45a049;
}

center {
    display: block;
    margin: 0 auto;
}

@media screen and (max-width: 768px) {
    .produkt {
        flex-direction: column;
        align-items: center;
        text-align: center;
        padding: 15px;
        width: 90%;
    }

    .zdjecie {
        width: 80%;
        height: 200px;
        margin-bottom: 20px;
    }

    .tekst {
        width: 80%;
        padding-left: 0;
    }

    #gora {
        font-size: 2rem;
    }

    button {
        width: auto;
    }
}

    </style>
</head>
<body>

    <!-- Header Section -->
    <div id="gora">
        <h1>Lego World</h1>
        <img src="koszyk.png" alt="Koszyk" onclick="toggleKoszyk()">
    </div>
    
    <!-- Koszyk (hidden off-screen initially) -->
    <div id="koszyk">
        <span id="closeKoszyk" onclick="toggleKoszyk()">×</span>
        <h2>Koszyk</h2>
        <ul id="koszykLista"></ul>
        <div id="koszykSuma">
            Suma: <span id="sumaWartosc">0.00 zł</span>
        </div>
        <button onclick="przejdzDoPlatnosci()">Przejdź do płatności</button>
    </div>

    <center>
        <div class="produkt"id=produkt1>
            <div id="zdjecie1" class="zdjecie"></div>
            <div class="tekst">
                <div>
                    Zestaw LEGO Ferrari to gratka dla fanów motoryzacji i klocków LEGO. Model wiernie odwzorowuje elegancję i dynamikę Ferrari, 
                    z detalami takimi jak otwierane drzwi, realistyczny silnik i charakterystyczne koła.
                </div>
                <div>
                    1899.99 zł<br>
                    <button onclick="dodajDoKoszyka('Zestaw LEGO Ferrari', '1899.99 zł',1)">Dodaj produkt do koszyka</button>
                </div>
            </div>
        </div>

        <div class="produkt"id=produkt2>
            <div id="zdjecie2" class="zdjecie"></div>
            <div class="tekst">
                <div>
                    Niesamowity zestaw LEGO, który pozwala zbudować legendarny model Lamborghini w wersji kolekcjonerskiej! 
                    Dzięki precyzyjnym detalom i realistycznemu odwzorowaniu supersamochodu ten zestaw zachwyci zarówno miłośników motoryzacji, jak i fanów budowania.
                </div>
                <div>
                    1899.99 zł<br>
                    <button onclick="dodajDoKoszyka('Zestaw LEGO Lamborghini', '1899.99 zł',2)">Dodaj produkt do koszyka</button>
                </div>
            </div>
        </div>

        <div class="produkt"id=produkt3>
            <div id="zdjecie3" class="zdjecie"></div>
            <div class="tekst">
                <div>
                    Wyjątkowy zestaw LEGO, który przenosi Cię na tor wyścigowy z zespołem Mercedes-AMG Petronas Formula One! 
                    Precyzyjnie odwzorowany bolid F1 oddaje wszystkie detale prawdziwego mistrza prędkości.
                </div>
                <div>
                    899.99 zł<br>
                    <button onclick="dodajDoKoszyka('Zestaw LEGO Mercedes F1', '899.99 zł',3)">Dodaj produkt do koszyka</button>
                </div>
            </div>
        </div>

        <div class="produkt"id=produkt4>
            <div id="zdjecie4" class="zdjecie"></div>
            <div class="tekst">
                <div>
                    Zestaw LEGO, który pozwala zbudować kultowy supersamochód Ford GT, znany z osiągów i legendarnych zwycięstw na torach wyścigowych.
                </div>
                <div>
                    1599.99 zł<br>
                    <button onclick="dodajDoKoszyka('Zestaw LEGO Ford GT', '1599.99 zł',4)">Dodaj produkt do koszyka</button>
                </div>
            </div>
        </div>

        <div class="produkt" id=produkt5>
            <div id="zdjecie5" class="zdjecie"></div>
            <div class="tekst">
                <div>
                    Lego Bugatti Chiron to szczegółowy zestaw konstrukcyjny, który pozwala zbudować model legendarnego samochodu sportowego w skali 1:8. 
                    Zestaw zawiera ponad 3,500 elementów, a gotowy model charakteryzuje się realistycznym wyglądem, funkcjonalnymi detalami.
                </div>
                <div>
                    1899.99 zł<br>
                    <button onclick="dodajDoKoszyka('Zestaw LEGO Bugatti Chiron', '1899.99 zł',5)">Dodaj produkt do koszyka</button>
                </div>
            </div>
        </div>

    </center>

    <script>
var isGuest = <?php echo $isGuest ? 'true' : 'false'; ?>;
var suma = 0;

function dodajDoKoszyka(nazwaProduktu, cenaProduktu, idProduktu) {
    const koszykLista = document.getElementById('koszykLista');
    const url = isGuest ? 'dodaj_do_koszyka_guest.php' : 'dodaj_do_koszyka.php';

    // Tworzenie nowego elementu listy
    const newLi = document.createElement('li');
    newLi.className = 'koszyk-item';
    
    const produktText = document.createElement('span');
    produktText.textContent = nazwaProduktu;
    
    const cenaText = document.createElement('span');
    cenaText.textContent = cenaProduktu;
    
    const usunBtn = document.createElement('button');
    usunBtn.textContent = 'Usuń';
    usunBtn.onclick = () => usunZKoszyka(newLi, cenaProduktu, idProduktu);

    newLi.appendChild(produktText);
    newLi.appendChild(cenaText);
    newLi.appendChild(usunBtn);
    koszykLista.appendChild(newLi);

    // Aktualizacja sumy
    let cena = parseFloat(cenaProduktu.replace(' zł', '').replace(',', '.'));
    suma += cena;
    document.getElementById('sumaWartosc').textContent = suma.toFixed(2) + ' zł';

    // Wysyłanie danych do serwera
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `idProduktu=${idProduktu}`
    })
    .then(response => response.json())
    .then(data => {
        if (!data.success) {
            alert(data.message);
        }
    })
    .catch(error => console.error('Błąd:', error));

    const koszyk = document.getElementById('koszyk');
    if (koszyk.style.right === '-300px' || koszyk.style.right === '') {
        toggleKoszyk();
    }
}

function usunZKoszyka(element, cenaProduktu, idProduktu) {
    const url = isGuest ? 'usun_z_koszyka_guest.php' : 'usun_z_koszyka.php';
    
    element.remove();

    let cena = parseFloat(cenaProduktu.replace(' zł', '').replace(',', '.'));
    suma -= cena;
    document.getElementById('sumaWartosc').textContent = suma.toFixed(2) + ' zł';

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `idProduktu=${idProduktu}`
    })
    .then(response => response.json())
    .then(data => {
        if (!data.success) {
            alert(data.message);
        }
    })
    .catch(error => console.error('Błąd:', error));
}

function toggleKoszyk() {
    const koszyk = document.getElementById('koszyk');
    if (koszyk.style.right === '0px' || koszyk.style.right === '') {
        koszyk.style.right = '-300px';
    } else {
        koszyk.style.right = '0px';
    }
}

function przejdzDoPlatnosci() {
    if (suma <= 0) {
        alert('Koszyk jest pusty!');
        return;
    }
    window.location.href = 'platnosc.php';
}
</script>
</body>
</html>