<?php
session_start();

if (!isset($_SESSION['guest']) || $_SESSION['guest'] !== true) {
    die(json_encode(['success' => false, 'message' => 'Brak dostępu']));
}

$conn = new mysqli('localhost', 'root', '', 'sklepinternetowy');

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Błąd połączenia z bazą']));
}

$idProduktu = isset($_POST['idProduktu']) ? (int)$_POST['idProduktu'] : 0;
$idGoscia = isset($_SESSION['id']) ? (int)$_SESSION['id'] : 0;

if ($idProduktu > 0 && $idGoscia > 0) {
    // Najpierw znajdujemy pierwszy wpis do usunięcia
    $sql = "SELECT id_goscia FROM koszyk_goscia 
            WHERE id_goscia = ? AND id_produkt = ? 
            LIMIT 1";
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $idGoscia, $idProduktu);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Usuwamy tylko jeden rekord
        $sql_delete = "DELETE FROM koszyk_goscia 
                      WHERE id_goscia = ? AND id_produkt = ? 
                      LIMIT 1";
                      
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("ii", $idGoscia, $idProduktu);
        
        if ($stmt_delete->execute()) {
            echo json_encode(['success' => true, 'message' => 'Produkt usunięty z koszyka']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Błąd podczas usuwania produktu']);
        }
        $stmt_delete->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Produkt nie znaleziony']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Nieprawidłowe dane']);
}

$conn->close();
?>