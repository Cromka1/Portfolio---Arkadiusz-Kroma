<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sklepinternetowy";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}

if (!isset($_SESSION['id'])) {
    echo json_encode(["success" => false, "message" => "Użytkownik nie jest zalogowany."]);
    exit();
}

$idUzytkownika = $_SESSION['id'];
$idProduktu = $_POST['idProduktu'] ?? null;

if (isset($idProduktu) && is_numeric($idProduktu)) {
    $sql = "INSERT INTO koszyk (id, id_produkt) VALUES ('$idUzytkownika', '$idProduktu')";
    
    if ($conn->query($sql) === TRUE) {
        $koszykId = $conn->insert_id;
        echo json_encode([
            "success" => true, 
            "message" => "Produkt został dodany do koszyka.",
            "koszykId" => $koszykId
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Błąd: " . $conn->error]);
    }
}

$conn->close();
?>