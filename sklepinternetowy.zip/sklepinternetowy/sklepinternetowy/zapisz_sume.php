<?php
session_start();

if(isset($_POST['suma'])) {
    $_SESSION['suma'] = number_format((float)$_POST['suma'], 2, '.', '');
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Brak sumy']);
}
?>