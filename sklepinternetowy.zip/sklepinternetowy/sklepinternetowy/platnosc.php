<?php
session_start();
$suma = isset($_SESSION['suma']) ? number_format((float)$_SESSION['suma'], 2, '.', '') : '0.00';
$isGuest = isset($_SESSION['guest']) && $_SESSION['guest'] === true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wybór płatności</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #ffffff;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #blokzplatnoscia {
            background: #000000;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 400px;
            border: 2px solid #DAA520;
        }

        h1 {
            font-family: 'Playfair Display', serif;
            color: #DAA520;
            margin-bottom: 10px;
            font-size: 28px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .price-display {
            color: #DAA520;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 30px;
            font-family: 'Poppins', sans-serif;
        }

        .price-display span {
            color: #ffffff;
            margin-left: 10px;
        }

        .payment-options {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 30px;
        }

        .payment-option {
            background: white;
            border: 2px solid #DAA520; 
            border-radius: 10px; 
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }

        .payment-option:hover {
            background: white;
            transform: translateY(-5px);
        }

        .payment-option img {
            width: 60px;
            height: 60px;
            margin-bottom: 10px;
        }

        .payment-option img[alt="Karta"] {
            width: 90px;
            height: 60px;
        }

        .payment-option p {
            color: #000000;
            margin: 0;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .payment-option:hover p {
            color: #DAA520;
        }

        .payment-option:hover img {
            filter: none;
        }

        .discount-container {
            margin-top: 30px;
            display: flex;
            gap: 10px;
        }

        #rabat {
            flex: 1;
            padding: 12px 15px;
            border: 2px solid #DAA520;
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            background: white;
            color: #000000;
            outline: none;
            transition: all 0.3s ease;
        }

        #rabat:focus {
            border-color: #ffffff;
            box-shadow: 0 0 10px rgba(218, 165, 32, 0.3);
        }

        #rabat::placeholder {
            color: #666666;
        }

        .discount-btn {
            padding: 12px 20px;
            background: #DAA520;
            border: none;
            border-radius: 8px;
            color: #000000;
            font-weight: 600;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .discount-btn:hover {
            background: #ffffff;
            color: #000000;
            box-shadow: 0 0 15px rgba(218, 165, 32, 0.3);
        }

        .submit-btn {
            background-color: #DAA520;
            color: #000000;
            border: none;
            border-radius: 8px;
            padding: 14px 30px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 30px;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            width: 100%;
        }

        .submit-btn:hover {
            background-color: #ffffff;
            color: #000000;
            box-shadow: 0 0 15px rgba(218, 165, 32, 0.5);
        }

        .submit-btn:disabled {
            background-color: #DAA520;
            cursor: not-allowed;
            color: black;
        }

        .payment-option.selected {
            background: #DAA520;
        }

        .payment-option.selected img {
            filter: none;
        }

        .payment-option.selected p {
            color: #000000;
        }
    </style>
</head>
<body>
    <div id="blokzplatnoscia">
        <center>
            <h1>Wybierz metodę płatności</h1>
            <div class="price-display">
                Do zapłaty: <span><?php echo $suma; ?> zł</span>
            </div>
            <form id="paymentForm">
                <div class="payment-options">
                    <div class="payment-option" onclick="togglePayment('blik')">
                        <img src="blik.jpg" alt="BLIK">
                        <p>BLIK</p>
                        <input type="hidden" name="payment_method" id="blik_input" value="">
                    </div>

                    <div class="payment-option" onclick="togglePayment('card')">
                        <img src="karta.png" alt="Karta">
                        <p>Karta płatnicza</p>
                        <input type="hidden" name="payment_method" id="card_input" value="">
                    </div>

                    <div class="payment-option" onclick="togglePayment('transfer')">
                        <img src="applepay.png" alt="Przelew">
                        <p>Applepay</p>
                        <input type="hidden" name="payment_method" id="transfer_input" value="">
                    </div>

                    <div class="payment-option" onclick="togglePayment('cash')">
                        <img src="paypal.png" alt="Gotówka">
                        <p>Paypal</p>
                        <input type="hidden" name="payment_method" id="cash_input" value="">
                    </div>
                </div>
                <?php if(!isset($_SESSION['guest']) || $_SESSION['guest'] === false): ?>
    <div class="discount-container">
        <input type="text" placeholder="Wpisz kod rabatowy" id="rabat">
        <button type="button" class="discount-btn" onclick="zatwierdzkodznizkowy()">
            Zatwierdź
        </button>
    </div>
<?php else: ?>
    <div style="margin: 20px 0; padding: 10px; background: rgba(218, 165, 32, 0.1); border-radius: 8px;">
        <p style="color: #DAA520; margin: 0; font-size: 14px; text-align: center;">
            Aby użyć kodu rabatowego, musisz się <a href="usercheck.php" style="color: #ffffff; text-decoration: underline;">zalogować</a> lub <a href="rejestracja.php" style="color: #ffffff; text-decoration: underline;">zarejestrować</a>
        </p>
    </div>
<?php endif; ?>
                <button type="submit" class="submit-btn" id="submitBtn" disabled>Zapłać</button>
            </form>
        </center>
    </div>

    <script>
var isGuest = <?php echo isset($_SESSION['guest']) && $_SESSION['guest'] ? 'true' : 'false'; ?>;
var suma = <?php echo $suma; ?>;

function togglePayment(method) {
    const allOptions = document.querySelectorAll('.payment-option');
    const clickedOption = document.querySelector(`.payment-option:has(#${method}_input)`);
    const submitBtn = document.getElementById('submitBtn');
    
    allOptions.forEach(option => {
        option.classList.remove('selected');
        const input = option.querySelector('input');
        if(input) input.value = '';
    });
    
    clickedOption.classList.add('selected');
    document.getElementById(`${method}_input`).value = method;
    submitBtn.disabled = false;
}

var kodyrabatowe = [
    {kod: "LEGO10", znizka: 10},
    {kod: "KLOCKI20", znizka: 20},
    {kod: "SUPER30", znizka: 30},
    {kod: "ZABAWKI15", znizka: 15},
    {kod: "PREZENT25", znizka: 25},
    {kod: "RABAT50", znizka: 50},
    {kod: "OKAZJA40", znizka: 40},
    {kod: "PROMO35", znizka: 35},
    {kod: "SPECIAL45", znizka: 45},
    {kod: "BONUS5", znizka: 5}
];

function zatwierdzkodznizkowy() {
    if (isGuest) {
        alert('Musisz być zalogowany, aby użyć kodu rabatowego!');
        return;
    }

    const kodRabatowy = document.getElementById('rabat').value.toUpperCase();
    const priceDisplay = document.querySelector('.price-display span');
    let currentPrice = parseFloat(priceDisplay.textContent);

    const znalezionyKod = kodyrabatowe.find(k => k.kod === kodRabatowy);
    
    if (znalezionyKod) {
        const znizka = znalezionyKod.znizka;
        const nowaKwota = currentPrice * (1 - znizka/100);
        priceDisplay.textContent = nowaKwota.toFixed(2) + ' zł';
        suma = nowaKwota;

        // Wyłącz pole z kodem rabatowym i przycisk po użyciu
        document.getElementById('rabat').disabled = true;
        document.querySelector('.discount-btn').disabled = true;

        alert(`Kod rabatowy ${kodRabatowy} został zastosowany! Zniżka: ${znizka}%`);
    } else {
        alert('Nieprawidłowy kod rabatowy!');
    }
}

function zaplac() {
    const selectedPayment = document.querySelector('.payment-option.selected');
    if (!selectedPayment) {
        alert('Proszę wybrać metodę płatności');
        return false;
    }

    const url = isGuest ? 'zapisz_zamowienie_guest.php' : 'zapisz_zamowienie.php';
    
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `suma=${suma}`
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert('Zapłacono! Dziękujemy za zakupy!');
            setTimeout(() => {
                window.location.href = 'glowna.php';
            }, 2000);
        } else {
            alert('Wystąpił błąd podczas zapisywania zamówienia');
        }
    })
    .catch(error => {
        console.error('Błąd:', error);
        alert('Wystąpił błąd podczas zapisywania zamówienia');
    });
}

// Dodaj na końcu pliku
document.getElementById('paymentForm').onsubmit = function(e) {
    e.preventDefault();
    zaplac();
    return false;
};

</script>
</body>
</html>