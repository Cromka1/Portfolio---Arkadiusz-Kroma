<?php
session_start();

$conn = new mysqli('localhost', 'root', '', 'sklepinternetowy');

// Dodaj gościa do tabeli guest_users
$sql = "INSERT INTO guest_users VALUES ()";
$conn->query($sql);
$guest_id = $conn->insert_id;

// Ustaw sesję
$_SESSION['id'] = $guest_id;
$_SESSION['guest'] = true;

$conn->close();

header("Location: glowna.php");
exit();
?>