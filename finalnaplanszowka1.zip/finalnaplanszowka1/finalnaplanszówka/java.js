var klikniecie = new Audio('840.mp3');
klikniecie.volume = 0.5;
function dzwiekprzycisku(){
    klikniecie.play();
}
function zaczynamy(){
    window.location.href = 'indexik.html';
    dzwiekprzycisku()
}
function zasady(){
    const information = document.getElementById("zasady");
    information.style.display = "block";
    dzwiekprzycisku()
}
function zamknij1() {
    const information = document.getElementById("zasady");
    information.style.display = "none";
    dzwiekprzycisku()
}


function tworcy(){
    const information = document.getElementById("tworcy");
    information.style.display = "block";
    dzwiekprzycisku()
}
function zamknij() {
    const information = document.getElementById("tworcy");
    information.style.display = "none";
    dzwiekprzycisku()
}