
var pytania1 = [
    "1. Jakie znaczenie ma skrót URL?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Uniform Resource Locator</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Universal Resource Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Unified Retrieval Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Unilateral Resource Link</button>",

    "2. Co to jest DOM?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Design Object Model </button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Data Object Model</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Document Object Model</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Digital Object Module</button>",

    "3. Które z poniższych jest oznaczeniem koloru w języku CSS?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Style: bold;</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Color: #FF0000;</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Text: red;</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Format: color(255, 0, 0);</button>",

    "4. Co oznacza skrót CMS w kontekście stron internetowych?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Content Management System</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Code Management System</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Cascading Menu System</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Creative Multimedia System</button>",

    "5. Jakie znaczenie ma skrót SEO?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Social Engagement Outreach</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Search Engine Optimization</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Secure Encryption Online</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Systematic Email Organization</button>",

    "6. Który element HTML jest stosowany do zagnieżdżania arkuszy stylów CSS?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) &lt;script&gt;</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) &lt;link&gt;</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) &lt;css&gt;</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) &lt;style&gt</button>",

    "7. Co oznacza skrót DNS?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Data Node Security</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Dynamic Network Server</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Digital Naming Service</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Domain Name System</button>",

    "8. Które z poniższych oznacza komentarz w języku HTML?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) // To jest komentarz</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) -- To jest komentarz;</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) /* To jest komentarz */</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) &lt;!-- To jest komentarz --&gt</button>",

    "9. Jakie jest znaczenie skrótu HTTP w kontekście komunikacji internetowej?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) HyperText Transfer Protocol</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Hyper Transferable Text Processing</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Hyperlink and Text Transmission</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) High-Level Text Protocol</button>",

    "10. Co to jest Bootstrap w kontekście projektowania stron internetowych?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Standardowy tag HTML</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Framework do budowania interfejsów użytkownika</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Protokół komunikacyjny</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Język programowania backendowego</button>",

    "11. Jakie są trzy podstawowe języki używane do tworzenia stron internetowych?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) HTML, CSS, JavaScript</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) CSS, Python, Java</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) HTML, CSS, Java</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Java, PHP, Ruby</button>",

    "12. Co to jest RWD w kontekście projektowania stron internetowych?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Responsive Web Design</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Retro Web Development</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Remote Web Debugging</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Rapid Web Deployment</button>",

    "13. Które z poniższych NIE jest prawidłowym selektorem CSS?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) #header</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) $footer</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) .main-content</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) p.intro</button>",

    "14. Który atrybut HTML jest używany do określania alternatywnego tekstu dla obrazu?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) src</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) title</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) alt</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) href</button>",

    "15. Co oznacza skrót HTTPS w przeglądarce internetowej?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) High-Level Text Processing System</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) HyperText Transfer Protocol Secure</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Hyperlink and Text Presentation System</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Hyper Transferable Security Protocol</button>",

    "16. Która z poniższych nie jest technologią backendową?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Node.js</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Django</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Flask</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) React</button>",

    "17. Co to jest Git?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Framework do budowania interfejsów użytkownika</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Protokół komunikacyjny</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Język programowania</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) System kontroli wersji</button>",

    "18. Jakie są zalety korzystania z technologii serverless w projektowaniu aplikacji?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Obniżenie kosztów utrzymania serwerów</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Zwiększenie złożoności kodu</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Brak możliwości skalowania</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Konieczność ręcznego zarządzania infrastrukturą</button>",

    "19. Co to jest RESTful API?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Remote Server Transfer and Language Application Programming Interface</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Representational State Transfer Application Programming Interface</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Responsive Style and Text Application Programming Interface</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Rapid System Transformation Application Programming Interface</button>",

    "20. Który z poniższych jest przykładem ataku XSS?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Cross-Site Scripting</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Cross-Site Request Forgery</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) SQL Injection</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Distributed Denial of Service</button>",

    "21. Które z poniższych NIE jest sposobem uwierzytelniania użytkowników w aplikacjach internetowych?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) SSH (Secure Shell)</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) OAuth</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) JWT (JSON Web Token)</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Basic Authentication</button>",

    "22. Co to jest WebSocket?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Protokół komunikacyjny umożliwiający dwukierunkową komunikację pomiędzy klientem a serwerem</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) System operacyjny do obsługi stron internetowych</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Framework do budowania interfejsów użytkownika</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Biblioteka JavaScript do manipulacji DOM</button>",

    "23. Które z poniższych jest przykładem protokołu komunikacyjnego?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) OAuth</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) SVG</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) TCP/IP</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) AJAX</button>",

    "24. Co to jest PWA?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Platform Web Application</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Python Web Analytics</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Public Web Access</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Progressive Web App</button>"
];

var pytania2 = [


    "25. Średnia ocen o szkole na Google ?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 2.6</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 3.2</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 2.1</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 2.9</button>",

    "26. Liczba komentarzy na Google ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 150</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 210</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 184</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 230</button>",

    "27. Jaki kolor ma godło szkoły ?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Czerwony</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Niebieski</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Zielony</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Żółty</button>",

    "28. Który nauczyciel jako jedyny prowadzi  jeden przedmiot sam/a ?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Kisiel Karina</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Borowska Bernarda</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Kujawski Janusz</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Miszkiewicz Konrad</button>",

    "29. Który nauczyciel prowadzi 3 przedmioty ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Kasperska Monika</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Gołuch Jacek</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Durczewski Maciej</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Malinowska Justyna</button>",

    "30. Jaki numer ma sala biologiczna ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 108</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 305</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 104</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 201</button>",

    "31. Jaki numer ma sala fizyczna ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 108</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 305</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 104</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 210</button>",

    "32. Jaki numer ma sala geograficzna ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 108</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 305</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 104</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 202</button>",

    "33. Co oznacza sygnał alarmowy kiedy Dźwięk dzwonka jest ciągły i trwa 2 minuty ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Pożar</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Włamanie</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Awaria techniczna</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Podejrzenie podłożenia bomby w szkole</button>",

    "34. Co oznacza sygnał alarmowy kiedy Dźwięk dzwonka jest przerywany i trwa 20 sekund ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Awaria elektryczna</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Wtargnięcie napastnika</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Trzęsienie ziemi</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Awaria systemu gazowego</button>",

    "35. Jak ma na nazwisko nauczyciel o imieniu taki samym jak sławny koszykarz który grał z numerem 23 i ma własną linię butów z Nike ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Kurc</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Jordan</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Wozniak</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Nowak</button>",

    "36. Ile jest profilów w ZSL ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 7</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 5</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 9</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 11</button>",

    "37. Co oznacza skrót ZSł ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Zespół Szkół Licealnych</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Zespół Szkół Łączności</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Zespół Szkół Logistycznych</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Zespół Szkół Lingwistycznych</button>",
    
    "38. Od ilu procent w naszej szkole jest ocena 3 ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 40%</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 60%</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 50%</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 45%</button>",
    
    "39. Na którym piętrze są sale dwucyfrowe ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Pierwszym</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Parter</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Drugim</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Trzecim</button>",
    
    "40. Kto jest na pierwszym miejscu w rankingach gdy nie jest to ZSł ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) ZSP</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) ZST</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) ZSE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) ZSK</button>",
    
    "41. Ile jest osób w dyrekcji szkoły ZSL? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 3</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 2</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 6</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 5</button>",
    
    "42. Jaki dokładny adres ma ówczesna szkoła ZSŁ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Przełajowa 4b</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Przełajowa 3b</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Przełajowa 4a</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Przełajowa 4c</button>",
    
    "43. Którą rocznicę naszego patrona szkoły obchodziliśmy ostatnio ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 56</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 59</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 52</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 50</button>",
    
    "44. Jaka nazwę ma bufet szkolny w ZSŁ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Łącznik</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Połacznik</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Łącze</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Łacznik</button>",

    "45. Kiedy będzie odbywał się dzień sportu w ZSŁ w 2024 roku ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 15 września</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 13 września</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 10 września</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 5 września</button>",

    "46. W którym roku powstało ZSŁ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 1946</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 1945</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 1970</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 1950</button>",

    "47. Kto był pierwszym Dyrektorem ZSŁ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Norbert Gierczak</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Łukasz Buk</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Mieczysław Nowicki</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Mikołaj Szulc</button>",

    "48. Kto jest obecnym dyrektorem ZSŁ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Marek Diament</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Damian Stolarski</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Adam Jóźwiak</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Jerzy Malecki</button>",
];
var pytania3 = [
    "49. Co to jest zmienna w programowaniu? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Przechowuje dane</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Funkcja wykonawcza</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Warunek logiczny</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Fragment kodu</button>",

    "50. Jakie są trzy podstawowe struktury danych w programowaniu? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Pętle, warunki, funkcje</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Stos, kolejka, drzewo</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Tablice, listy, krotki</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Zmienne, stałe, funkcje</button>",

    "51. Który z poniższych nie jest typem danych w bazie danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) List</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) String</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Float</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Int</button>",

    "52. Jakie są podstawowe operacje CRUD w bazach danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Create, Read, Update, Delete</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Copy, Remove, Undo, Display</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Cut, Rename, Append, Save</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Connect, Retrieve, Utilize, Deploy</button>",

    "53. Jakie jest standardowe polecenie SQL do wybierania danych z bazy danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) GET</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) SELECT</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) RETRIEVE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) FETCH</button>",

    "54. Co oznacza akronim SQL? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) System Query Logic </button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Simple Query Logic</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Sequential Query Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Structured Query Language</button>",

    "55. Która instrukcja SQL służy do dodawania danych do tabeli? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) CREATE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) UPDATE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) ADD</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) INSERT INTO</button>",

    "56. W którym języku programowania definiuje się zmienną za pomocą operatora '='? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Java </button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) JavaScript</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) C++</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Python</button>",

    "57. Co oznacza akronim HTML? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Hyper Text Markup Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Hyper Transfer Markup Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Hyper Transfer Modem Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) High Text Modem Language</button>",

    "58. Jakie są dwa podstawowe sposoby deklarowania funkcji w języku JavaScript? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) func() i declare()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) function() i define()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) function() i var()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) define() i create()</button>",

    "59. Który z poniższych operatorów w języku JavaScript jest używany do łączenia ciągów znaków? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) +</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) *</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) /</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) -</button>",

    "60. Które polecenie w języku SQL służy do usuwania danych z bazy danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) DELETE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) DROP</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) REMOVE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) CLEAN</button>",

    "61. Co oznacza akronim CSS? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Computer Style Sheets</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Cascading Style Sheets</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Creative Style Sheets</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Custom Style Sheets</button>",

    "62. Który z poniższych nie jest językiem programowania? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Python</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Java</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) HTML</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Ruby</button>",

    "63. Jakie jest standardowe polecenie SQL do aktualizacji danych w bazie danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) MODIFY</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) UPDATE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) ALTER</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) CHANGE</button>",

    "64. Co to jest pętla w programowaniu? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Element graficzny</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Funkcja matematyczna</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Warunek logiczny</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Fragment kodu, który wykonuje się wielokrotnie</button>",

    "65. Która z poniższych funkcji w języku Python służy do obliczania długości listy? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) size()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) length()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) count()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) len()</button>",

    "66. Jakie jest standardowe polecenie SQL do tworzenia nowej tabeli w bazie danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) CREATE TABLE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) ADD TABLE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) MAKE TABLE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) NEW TABLE</button>",

    "67. Które z poniższych nie jest typem danych w języku JavaScript? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Boolean</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Character</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Undefined</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Object</button>",

    "68. Co oznacza akronim API? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Application Programming Interface</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Advanced Programming Interface</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Automated Program Interaction</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Advanced Protocol Integration</button>",

    "69. Które z poniższych nie jest znacznikiem HTML? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">paragraph</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\"> header</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\"> script</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\"> body</button>",

    "70. Jakie jest standardowe polecenie SQL do usuwania tabeli z bazy danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) DROP TABLE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) DELETE TABLE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) REMOVE TABLE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) ERASE TABLE</button>",

    "71. W którym języku programowania instrukcja + 'if' + służy do wykonania określonych działań w zależności od warunku logicznego? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) CSS</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) HTML</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Python</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) SQL</button>",

    "72. Co oznacza akronim XML? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Extended Markup Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Extra Modem Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Excessive Modulation Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Extensible Markup Language</button>",
];
var pytania4 = [
    "73. Która w rankingu technikum w Poznaniu jest ZSŁ?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 2</button> <br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 4</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 3</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 1</button>",

    "74. W którym roku została założona szkoła ZSŁ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 1940</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 1950</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 1946</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 1941</button>",

    "75. Jakiego rodzaju jest najczęściej jedzenie na stołówce ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) wegańskiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) mięsnego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) wegetariańskiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) nie wiem nie jem</button>",

    "76. Jak ma na imię nauczyciel którego nazwisko jest kojarzone z zawodem stolarz ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Damian</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Kacper</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Jakub</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Łukasz</button>",

    "77. Kto jest wychowawcą klasy 2p1T? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Borkowski Damian</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Adamek Anna</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Adamek Marcin</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Charaś Marta</button>",

    "78. Kto zajmuje się wymianami uczniów za granicę w ZSŁ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Gojtka Ewa</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Celka Natalia</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Giera Piotr</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Magdalena Jurczyk-Maciuszonek</button>",

    "79. Który nauczyciel był na Antarktydzie? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Handkiewicz Edyta</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Natunewicz Marta</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Witkowska Agata</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Tomczak Grzegorz</button>",

    "80. Czego uczy pan Durczewski? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) biologii</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) angielskiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) niemieckiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) chemii</button>",

    "81. Czego uczy pan Czosnowski? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) biologii</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) przedmiotów zawodowych</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) niemieckiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) fizyki</button>",

    "82. Czego uczy pan Osiński? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) angielskiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) historii</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) niemieckiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) przedmiotów zawodowych</button>",

    "83. Czego uczy pani która jest od nie dawna w ZSL a wcześniej uczyła w Warszawie ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) polskiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) niemieckiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) hiszpańskiego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) chemii</button>",

    "84. Ile kosztuje obiad z surówką na stołówce ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 24</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 20</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 23</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 22</button>",

    "85. Kto jest przewodniczącym su (Samorządu uczniowskiego) ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Marcin Nogajewski</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Michał Strykowski</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Mateusz Hildebrandt</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Mateusz Kulus</button>",

    "86. Od której godzinny jest czynna jest biblioteka w poniedziałki ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 7:20</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 10:00</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 7:30</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 9:00</button>",

    "87. Który nauczyciel miał być prowadzącym kółka kulinarnego jagby powstało w ZSL ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Damian Stolarski</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Mikołaj Czosnowski</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Jordan Kurc</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Anna Adamek</button>",

    "88. Ktory z nauczycieli religi udziela mszy w kościele św Boromeusza w Poznaniu ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Gołuch Jacek</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Zakrzewski Marek</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Mańczak Marcin</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Jakub Proch</button>",

    "89. Z którym nauczycielem/kom odbywają się lekcje matematyki w sali 203? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Gojtka Ewa</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Mieczyński Tadeusz</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Gotowicz Katarzyna</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Paszyn Iwona</button>",

    "90. Ktory z nauczycieli jest wielkim miłośnikiem szachów i prowadzi konkursy szachowe w naszej szkole ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Staniszewski Paweł</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b)Maciejewska Agnieszka</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Krawczyk Mateusz</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Paprzycka Katarzyna</button>",

    "91.Ktorego dnia w zeszłym roku odbyła się wigilia klasowa w naszej szkole ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 23 grudnia</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 21 grudnia</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 22 grudnia</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 20 grudnia</button>",

    "92.Ktory dzień jest obchodzony jako dzień Mikołaja Kopernika ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 19 lutego</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 20 stycznia</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 20 maja</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 21 maja</button>",

    "93. Po ile złotych były sprzedawane paczki w tłusty czwartek w naszej szkole ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 1 zł</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 3 zł</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 2 zł</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 0.50 zł</button>",

    "94. Jak ma na imię uczeń który zbiera już od dłuższego czasu materiały na budowę turbiny wiatrowej w naszej szkole ? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a)  Antek</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Bartek</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Wojtek</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Oskar</button>",

    "95. Ile było w sumie dyrektorów ZSL (łącznie z obecnym)? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) 6</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) 4</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) 7</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) 3</button>",

    "96. Który z poniższych jest frameworkiem języka JavaScript? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Django</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Flask</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Ruby on Rails</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) React</button>",
];

var pytania5 = [
    "97. Co oznacza akronim JSON? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) JavaScript Object Notation</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Javascript Official Notation </button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) JavaScript Ordered Notation</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Java Serialized Object Notation</button>",

    "98. Co oznacza skrót API w kontekście programowania?<br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Automated Program Interaction</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Advanced Protocol Integration</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Application Programming Interface </button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Algorithmic Programming Interface</button>",

    "99. Jakie są dwa podstawowe typy danych w języku SQL? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Integer i Float</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Numeric i Date</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) String i Character</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Text i Boolean</button>",

    "100. Który z poniższych nie jest typem danych w języku CSS? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Length</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) String</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Color</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Integer</button>",

    "101. Który z poniższych nie jest językiem programowania? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Python</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) HTML</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Java</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Ruby</button>",

    "102. Jakie jest standardowe polecenie SQL do aktualizacji danych w bazie danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) CHANGE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) MODIFY</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) ALTER</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) UPDATE</button>",

    "103. Który z poniższych operatorów w języku JavaScript służy do obliczania reszty z dzielenia? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) -</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) /</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) *</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) %</button>",

    "104. Który operator w języku Python jest używany do sprawdzenia czy dany element znajduje się w danym zbiorze? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) contains</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) not</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) exist</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) in</button>",

    "105. Jakie jest standardowe polecenie SQL do wybierania unikatowych wartości z kolumny? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) DISTINCT</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) UNIQUE</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) UNIQUE()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) MIN</button>",

    "106. Co oznacza akronim ORM w kontekście baz danych? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Object-Related Model</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Object-Relational Mapping</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Object-Result Mapping</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Object-Resource Management</button>",

    "107. Która z poniższych metod jest używana w języku Python do sortowania listy? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) sort()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) order()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c)arrange()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) organize()</button>",

    "108. Który operator w języku Python jest używany do wykonania dzielenia z zaokrągleniem w dół? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) //</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) /</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) %</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) -:</button>",

    "109. Co oznacza akronim URL? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Universal Relational Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Universal Resource Locator</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Uniform Resource Language</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Unified Resource Library</button>",

    "110. Które z poniższych słów kluczowych jest używane do definiowania funkcji w języku Python? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) function</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) define</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) def</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) func </button>",

    "111. Jakie są dwa podstawowe typy danych w języku SQL? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Integer i Float</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Numeric i Date</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) String i Character</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Text i Boolean</button>",

    "112. Który z poniższych nie jest typem danych w języku C++? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Integer</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) String</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Float</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Length</button>",

    "113. Jakie są główne typy danych w Pythonie? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Char, int, float, bool, list, tuple, dict</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Char, int</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Char, int, double, bool, array, list</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) String, int, float, bool, list, dict</button>",

    "114. Które z poniższych są typami danych w języku Python? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) String, integer, float, boolean</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) String, int, double, bool</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Text, number, array, bool</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) array, bool</button>",

    "115. W jaki sposób można zadeklarować zmienną w języku Python? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) Za pomocą operatora ':'</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Za pomocą operatora '='</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Za pomocą operatora '=='</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Za pomocą operatora '++'</button>",

    "116. Co oznacza akronim JSON? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) JavaScript Object Notation</button><br><button class='przycisk' onclick=\"(Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) JavaScript Ordered Nordic</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\"> c) JavaScript Ordered Notation</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Java Serialized Object Notation</button>",

    "117. Który z poniższych jest frameworkiem języka JavaScript? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) React</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) Flask</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) Ruby on Rails</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) Django</button>",

    "118. W jaki sposób deklaruje się komentarz jednolinijkowy w języku Python? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) #</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) //</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) --</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) <!-- </button>",

    "119. Która z poniższych funkcji w języku Python służy do obliczania potęgi? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) pow()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) power()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) **()</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) ^()</button>",

    "120. Który operator w języku Python jest używany do sprawdzenia czy dany element znajduje się w danym zbiorze? <br><button class='przycisk' onclick=\"Twojaodpowiedz('a',pomocnicze1, pomocnicze2)\">a) contains</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('b',pomocnicze1, pomocnicze2)\">b) not</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('c',pomocnicze1, pomocnicze2)\">c) exist</button><br><button class='przycisk' onclick=\"Twojaodpowiedz('d',pomocnicze1, pomocnicze2)\">d) in</button>", 
];
var zdarzenia = [
    'Wylądowałeś na dywaniku u dyrektora. Cofasz się o 5 pól',
    'Spadłeś ze schodów i złamałeś ręke. Cofasz się o 4 pola',
    'Wylałeś sok na komputer. Cofasz się o 3 pola',
    'Przyłapano cię na ściąganiu. Cofasz się o 2 pola',
    'Dostałeś uwagę za korzystanie z telefonu w trakcie lekcji. Cofasz się o jedno pole',
    'Dostałeś plusa za aktywność na lekcji. Idziesz jedno pole do przodu.',
    'Na w-fie jest piłka nożna. Idziesz o 2 pola do przodu',
    'Dostałeś 6 z baz danych. Idziesz 3 pola do przodu',
    'Otrzymałeś pochwałę dyrektora. Idziesz o 4 pola do przodu',
    'Na koniec roku wychodzi ci pasek. Idziesz 5 pól do przodu',
    'Wrzuciłeś petardę do sali nr 24 i zostałeś przyłapany. Cofasz się o 5 pól',
    'Wychodzi ci 1 na semestr z bilogii. Cofasz się o 4 pola',
    'Dostałeś piłką w twarz i masz złamany nos. Cofasz się o 3 pola',
    'Poślizgnąłeś się na skórce od banana. Cofasz się o 2 pola',
    'Dostałeś minusa za przeszkadzanie na fizyce. Cofasz się o jedno pole',
    'Twoja drużyna wygrała na w-fie. Idziesz jedno pole do przodu',
    'Znalazłeś żeton na podłodze. Idziesz 2 pola do przodu',
    'Dostałeś gotowca na kartkówkę. Idziesz 3 pola do przodu',
    'Dostałeś się na praktyki w Hiszpanii. Idziesz 4 pola do przodu',
    'Wygrałeś konkurs Huwaweia. Idziesz 5 pól do przodu',
    'Przyłapano cię na paleniu w toalecie i wezwano twoich rodziców. Cofasz się o 5 pól',
    'Zostałeś pobity za donosicielstwo. Cofasz się o 4 pola',
    'W trakcie spaceru na w-fie prawie potrącił cię samochód. Cofasz się o 3 pola',
    'Zgubiłeś żeton na obiad. Cofasz się o 2 pola',
    'Zgubiłeś ściągę. Cofasz się o jedno pole',
    'W ostatniej chwili zdążyłeś na tramwaj. Idziesz o jedno pole do przodu',
    'Pożyczyłeś koledze długopis. Idziesz 2 pola do przodu za dobre serce',
    'W trakcie kartkówki na którą nic nie umiałeś wybuchł pożar. Idziesz 3 pola do przodu',
    'W szkole jest podejrzenie bomby i zostaliście wysłani na zdalne nauczanie. Idziesz 4 pola do przodu',
    'Po trzech miesiącach czekania w końcu kolega wysłał ci pytania. Idziesz o 5 pól do przodu',
    'Wysłałeś koledze kartkówke z baz danych, a ten odesłał ją panu nic nie zmieniając przez co obaj dostaliście 1. Cofasz się o 5 pól',
    'Kolega oddał ci zaległe 40 złotych. Idziesz 5 pól do przodu'
]
var przesuniecia = {
    'Wylądowałeś na dywaniku u dyrektora. Cofasz się o 5 pól': -5,
    'Spadłeś ze schodów i złamałeś ręke. Cofasz się o 4 pola': -4,
    'Wylałeś sok na komputer. Cofasz się o 3 pola': -3,
    'Przyłapano cię na ściąganiu. Cofasz się o 2 pola': -2,
    'Dostałeś uwagę za korzystanie z telefonu w trakcie lekcji. Cofasz się o jedno pole': -1,
    'Dostałeś plusa za aktywność na lekcji. Idziesz jedno pole do przodu.': 1,
    'Na w-fie jest piłka nożna. Idziesz o 2 pola do przodu': 2,
    'Dostałeś 6 z baz danych. Idziesz 3 pola do przodu': 3,
    'Otrzymałeś pochwałę dyrektora. Idziesz o 4 pola do przodu': 4,
    'Na koniec roku wychodzi ci pasek. Idziesz 5 pól do przodu': 5,
    'Wrzuciłeś petardę do sali nr 24 i zostałeś przyłapany. Cofasz się o 5 pól': -5,
    'Wychodzi ci 1 na semestr z bilogii. Cofasz się o 4 pola': -4,
    'Dostałeś piłką w twarz i masz złamany nos. Cofasz się o 3 pola': -3,
    'Poślizgnąłeś się na skórce od banana. Cofasz się o 2 pola': -2,
    'Dostałeś minusa za przeszkadzanie na fizyce. Cofasz się o jedno pole': -1,
    'Twoja drużyna wygrała na w-fie. Idziesz jedno pole do przodu': 1,
    'Znalazłeś żeton na podłodze. Idziesz 2 pola do przodu': 2,
    'Dostałeś gotowca na kartkówkę. Idziesz 3 pola do przodu': 3,
    'Dostałeś się na praktyki w Hiszpanii. Idziesz 4 pola do przodu': 4,
    'Wygrałeś konkurs Huwaweia. Idziesz 5 pól do przodu': 5,
    'Przyłapano cię na paleniu w toalecie i wezwano twoich rodziców. Cofasz się o 5 pól': -5,
    'Zostałeś pobity za donosicielstwo. Cofasz się o 4 pola': -4,
    'W trakcie spaceru na w-fie prawie potrącił cię samochód. Cofasz się o 3 pola': -3,
    'Zgubiłeś żeton na obiad. Cofasz się o 2 pola': -2,
    'Zgubiłeś ściągę. Cofasz się o jedno pole': -1,
    'W ostatniej chwili zdążyłeś na tramwaj. Idziesz o jedno pole do przodu': 1,
    'Pożyczyłeś koledze długopis. Idziesz 2 pola do przodu za dobre serce': 2,
    'W trakcie kartkówki na którą nic nie umiałeś wybuchł pożar. Idziesz 3 pola do przodu': 3,
    'W szkole jest podejrzenie bomby i zostaliście wysłani na zdalne nauczanie. Idziesz 4 pola do przodu': 4,
    'Po trzech miesiącach czekania w końcu kolega wysłał ci pytania. Idziesz o 5 pól do przodu': 5,
    'Wysłałeś koledze kartkówke z baz danych, a ten odesłał ją panu nic nie zmieniając przez co obaj dostaliście 1. Cofasz się o 5 pól': -5,
    'Kolega oddał ci zaległe 40 złotych. Idziesz 5 pól do przodu': 5
};
var poprawneodpowiedzi1 = [
    'a','c','b','a','b','d','d','d','a','b','a','a','b','c','b','d','d','a','b','a','a','a','c','d'
];
var poprawneodpowiedzi2 = [
    'a','c','b','a','b','d','d','d','a','b','a','a','b','c','b','d','d','a','b','a','a','a','c','d'
];
var poprawneodpowiedzi3 = [
    'a','c','b','a','b','d','d','d','a','b','a','a','b','c','b','d','d','a','b','a','a','a','c','d'
];
var poprawneodpowiedzi4 = [
    'a','c','b','a','b','d','d','d','a','b','a','a','b','c','b','d','d','a','b','a','a','a','c','d'
];
var poprawneodpowiedzi5 = [
    'a','c','b','a','b','d','d','d','a','b','a','a','b','c','b','d','d','a','b','a','a','a','c','d'
];
var dzwiek = new Audio('7576.mp3');
var blednaodpowiedz = new Audio('za-odpowiedz_Wby39Cb.mp3')
var chodzenie = new Audio('19338.mp3');
chodzenie.volume = 0.4;
blednaodpowiedz.volume = 0.2;
dzwiek.volume = 0.3;
var klikniecie = new Audio('840.mp3');
klikniecie.volume = 0.5;
function dzwiekprzycisku(){                                                          
    klikniecie.play();
}
function dzwiekpoprawnejodpowiedzi() {
    dzwiek.play();
}
function dzwiekblednejodpowiedzi(){
    blednaodpowiedz.play();
}
function dzwiekchodzenia(){
    chodzenie.play();
}
var odpowiedzbledna1=false;
var odpowiedzbledna2=false;
var odpowiedzbledna3=false;
var odpowiedzbledna4=false;
var odpowiedzbledna5=false;
var sumaodpowiedzip1 = 0;
var sumapoprawnychodpowiedzip1 = 0;
var sumaodpowiedzip2 = 0;
var sumapoprawnychodpowiedzip2 = 0;
var sumaodpowiedzip3 = 0;
var sumapoprawnychodpowiedzip3 = 0;
var sumaodpowiedzip4 = 0;
var sumapoprawnychodpowiedzip4 = 0;
var sumaodpowiedzip5 = 0;
var sumapoprawnychodpowiedzip5 = 0;
function Twojaodpowiedz(odpowiedz, pomocnicze1, pomocnicze2) {
    dzwiekprzycisku();
    if (actualplayer == 1) {
        var i = 0;
        var pomocnicze3 = eval("poprawneodpowiedzi" + pomocnicze1);
        console.log("pomocnicze 3: " + pomocnicze3)
        console.log("warunek " + pomocnicze3[pomocnicze2])
        function chodzeniep1() {
            if(actualpositionp1>1){
                var poprzedniePole = document.getElementById("pole" + (actualpositionp1 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P1.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
            }
            document.getElementById("pole" + actualpositionp1).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp1++
            console.log("pozycja p1: " + actualpositionp1)
            dzwiekchodzenia();
            
            if (czytanieWlaczone) {
                czytamy();
            }
            if (i < 2) {
                i++;
                setTimeout(chodzeniep1, 400);
                return;
            }
        }
        if (odpowiedz === pomocnicze3[pomocnicze2]) {
            sumapoprawnychodpowiedzip1++
            sumaodpowiedzip1++
            alert("Gratulujemy poprawnej odpowiedzi !!!");
            dzwiekpoprawnejodpowiedzi();
            chodzeniep1();
        } 
        else {
            function chodzeniedotylup1() {
                var poprzedniePole = document.getElementById("pole" + actualpositionp1);
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P1.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                dzwiekchodzenia();
                if (actualpositionp1 >= 0) {
                    actualpositionp1--;
                    aktualnapozycjaplusjeden1 = actualpositionp1 + 1;
                    console.log("pozycja p1: " + aktualnapozycjaplusjeden1);
                    if (actualpositionp1 < 1) {
                        actualpositionp1 = 0;
                    }
                    document.getElementById("pole" + actualpositionp1).style.backgroundImage = "url(P" + actualplayer + ".png)";
                    if (i < 2) {
                        i++;
                        setTimeout(chodzeniedotylup1, 400);
                        return;
                    }
                }

                var obecnePole = document.getElementById("pole" + actualpositionp1);
                if (obecnePole) {
                    obecnePole.style.backgroundImage = "url(P" + actualplayer + ".png)";
                }

                if (czytanieWlaczone) {
                    czytamy();
                }
            }
            sumaodpowiedzip1++;
            alert("Niestety odpowiedziałeś źle");
            dzwiekblednejodpowiedzi();
            chodzeniedotylup1();
            odpowiedzbledna1 = true
        }
        if (actualpositionp1 == 0) {
            actualpositionp1++;
        }
    }


    if (actualplayer == 2) {
        var i = 0;
        var pomocnicze3 = eval("poprawneodpowiedzi" + pomocnicze1);
        console.log("pomocnicze 3: " + pomocnicze3)
        console.log("warunek " + pomocnicze3[pomocnicze2])
        function chodzeniep2() {
            if(actualpositionp2>1){
                var poprzedniePole = document.getElementById("pole" + (actualpositionp2 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P2.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
            }
            document.getElementById("pole" + actualpositionp2).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp2++
            console.log("pozycja p2: " + actualpositionp2)
            dzwiekchodzenia();
            if (czytanieWlaczone) {
                czytamy();
            }
            
            if (i < 2) {
                i++;
                setTimeout(chodzeniep2, 400);
                return;
            }
        }
        if (odpowiedz === pomocnicze3[pomocnicze2]) {
            sumapoprawnychodpowiedzip2++
            sumaodpowiedzip2++
            alert("Gratulujemy poprawnej odpowiedzi !!!");
            dzwiekpoprawnejodpowiedzi();
            chodzeniep2();
        } 
        else {
            function chodzeniedotylup2() {
                var poprzedniePole = document.getElementById("pole" + actualpositionp2);
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P2.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                dzwiekchodzenia();
                if (actualpositionp2 >= 0) {
                    actualpositionp2--;
                    var aktualnapozycjaplusjeden2 = actualpositionp2 + 1;
                    console.log("pozycja p2: " + aktualnapozycjaplusjeden2);
                    if (actualpositionp2 < 1) {
                        actualpositionp2 = 0;
                    }
                    document.getElementById("pole" + actualpositionp2).style.backgroundImage = "url(P" + actualplayer + ".png)";
                    if (i < 2) {
                        i++;
                        setTimeout(chodzeniedotylup2, 400);
                        return;
                    }
                }
                var obecnePole = document.getElementById("pole" + actualpositionp2);
                if (obecnePole) {
                    obecnePole.style.backgroundImage = "url(P" + actualplayer + ".png)";
                }
                if (czytanieWlaczone) {
                    czytamy();
                }
            }
            sumaodpowiedzip2++;
            alert("Niestety odpowiedziałeś źle");
            dzwiekblednejodpowiedzi();
            chodzeniedotylup2();
            odpowiedzbledna2 = true
        }
        if (actualpositionp2 == 0) {
            actualpositionp2++;
        }
    }

    if (actualplayer == 3) {
        var i = 0;
        var pomocnicze3 = eval("poprawneodpowiedzi" + pomocnicze1);
        console.log("pomocnicze 3: " + pomocnicze3)
        console.log("warunek " + pomocnicze3[pomocnicze2])
        function chodzeniep3() {
            if(actualpositionp3>1){
                var poprzedniePole = document.getElementById("pole" + (actualpositionp3 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P3.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
            }
            var poprzedniePole = document.getElementById("pole" + (actualpositionp3 - 1));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P3.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp3).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp3++
            console.log("pozycja p3: " + actualpositionp3)
            dzwiekchodzenia();
        
            if (czytanieWlaczone) {
                czytamy();
            }
            
            if (i < 2) {
                i++;
                setTimeout(chodzeniep3, 400);
                return;
            }
        }
        if (odpowiedz === pomocnicze3[pomocnicze2]) {
            sumapoprawnychodpowiedzip3++
            sumaodpowiedzip3++
            alert("Gratulujemy poprawnej odpowiedzi !!!");
            dzwiekpoprawnejodpowiedzi();
            chodzeniep3();
        } 
        else {
            function chodzeniedotylup3() {
                var poprzedniePole = document.getElementById("pole" + actualpositionp3);
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P3.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                dzwiekchodzenia();
                if (actualpositionp3 >= 0) {
                    actualpositionp3--;
                    var aktualnapozycjaplusjeden3 = actualpositionp3 + 1;
                    console.log("pozycja p3: " + aktualnapozycjaplusjeden3);
                    if (actualpositionp3 < 1) {
                        actualpositionp3 = 0;
                    }
                    document.getElementById("pole" + actualpositionp3).style.backgroundImage = "url(P" + actualplayer + ".png)";
                    if (i < 2) {
                        i++;
                        setTimeout(chodzeniedotylup3, 400);
                        return;
                    }
                }
                var obecnePole = document.getElementById("pole" + actualpositionp3);
                if (obecnePole) {
                    obecnePole.style.backgroundImage = "url(P" + actualplayer + ".png)";
                }
                if (czytanieWlaczone) {
                    czytamy();
                }
            }
            sumaodpowiedzip3++;
            alert("Niestety odpowiedziałeś źle");
            dzwiekblednejodpowiedzi();
            chodzeniedotylup3();
            odpowiedzbledna3 = true
        }
        if (actualpositionp3 == 0) {
            actualpositionp3++;
        }
    }

    if (actualplayer == 4) {
        var i = 0;
        var pomocnicze3 = eval("poprawneodpowiedzi" + pomocnicze1);
        console.log("pomocnicze 3: " + pomocnicze3)
        console.log("warunek " + pomocnicze3[pomocnicze2])
        function chodzeniep4() {
            if(actualpositionp4>1){
                var poprzedniePole = document.getElementById("pole" + (actualpositionp4 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P4.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
            }
            
            document.getElementById("pole" + actualpositionp4).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp4++
            console.log("pozycja p4: " + actualpositionp4)
            dzwiekchodzenia();
            
            
            if (czytanieWlaczone) {
                czytamy();
            }
            if (i < 2) {
                i++;
                setTimeout(chodzeniep4, 400);
                return;
            }
        }
        if (odpowiedz === pomocnicze3[pomocnicze2]) {
            sumapoprawnychodpowiedzip4++
            sumaodpowiedzip4++
            alert("Gratulujemy poprawnej odpowiedzi !!!");
            dzwiekpoprawnejodpowiedzi();
            chodzeniep4();
        } 
        else {
            function chodzeniedotylup4() {
                var poprzedniePole = document.getElementById("pole" + actualpositionp4);
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P4.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                dzwiekchodzenia();
                if (actualpositionp4 >= 0) {
                    actualpositionp4--;
                    var aktualnapozycjaplusjeden4 = actualpositionp4 + 1;
                    console.log("pozycja p4: " + aktualnapozycjaplusjeden4);
                    if (actualpositionp4 < 1) {
                        actualpositionp4 = 0;
                    }
                    document.getElementById("pole" + actualpositionp4).style.backgroundImage = "url(P" + actualplayer + ".png)";
                    if (i < 2) {
                        i++;
                        setTimeout(chodzeniedotylup4, 400);
                        return;
                    }
                }
                var obecnePole = document.getElementById("pole" + actualpositionp4);
                if (obecnePole) {
                    obecnePole.style.backgroundImage = "url(P" + actualplayer + ".png)";
                }
                if (czytanieWlaczone) {
                    czytamy();
                }
            }
            sumaodpowiedzip4++;
            alert("Niestety odpowiedziałeś źle");
            dzwiekblednejodpowiedzi();
            chodzeniedotylup4();
            odpowiedzbledna4 = true
        }
        if (actualpositionp4 == 0) {
            actualpositionp4++;
        }
    }

    if (actualplayer == 5) {
        var i = 0;
        var pomocnicze3 = eval("poprawneodpowiedzi" + pomocnicze1);
        console.log("pomocnicze 3: " + pomocnicze3)
        console.log("warunek " + pomocnicze3[pomocnicze2])
        function chodzeniep5() {
            if(actualpositionp5>1){
                var poprzedniePole = document.getElementById("pole" + (actualpositionp5 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P5.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
            }
            document.getElementById("pole" + actualpositionp5).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp5++
            console.log("pozycja p5: " + actualpositionp5)
            dzwiekchodzenia();
            
            if (czytanieWlaczone) {
                czytamy();
            }
            
            if (i < 2) {
                i++;
                setTimeout(chodzeniep5, 400);
                return;
            }
        }
        if (odpowiedz === pomocnicze3[pomocnicze2]) {
            sumapoprawnychodpowiedzip5++
            sumaodpowiedzip5++
            alert("Gratulujemy poprawnej odpowiedzi !!!");
            dzwiekpoprawnejodpowiedzi();
            chodzeniep5();
        } 
        else {
            function chodzeniedotylup5() {
                var poprzedniePole = document.getElementById("pole" + actualpositionp5);
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P5.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                dzwiekchodzenia();
                if (actualpositionp5 >= 0) {
                    actualpositionp5--;
                    var aktualnapozycjaplusjeden5 = actualpositionp5 + 1;
                    console.log("pozycja p5: " + aktualnapozycjaplusjeden5);
                    if (actualpositionp5 < 1) {
                        actualpositionp5 = 0;
                    }
                    document.getElementById("pole" + actualpositionp5).style.backgroundImage = "url(P" + actualplayer + ".png)";
                    if (i < 2) {
                        i++;
                        setTimeout(chodzeniedotylup5, 400);
                        return;
                    }
                }
                var obecnePole = document.getElementById("pole" + actualpositionp5);
                if (obecnePole) {
                    obecnePole.style.backgroundImage = "url(P" + actualplayer + ".png)";
                }
                if (czytanieWlaczone) {
                    czytamy();
                }
            }
            sumaodpowiedzip5++;
            alert("Niestety odpowiedziałeś źle");
            dzwiekblednejodpowiedzi();
            chodzeniedotylup5();
            odpowiedzbledna5 = true
        }
        if (actualpositionp5 == 0) {
            actualpositionp5++;
        }
    }
    
    document.getElementById("losowanie").disabled = false;
    document.querySelector(".pytania").innerHTML = "Wybrałeś już odpowiedź :)"
}

var czytanieWlaczone = false; 
function czytanie() {
    dzwiekprzycisku()
    czytanieWlaczone = !czytanieWlaczone; 

    if (czytanieWlaczone) {
        document.getElementById("czytanko").innerHTML = "<p>Wyłącz czytanie</p>"; 
        czytamy(); 
    } else {
        document.getElementById("czytanko").textContent = "<p>Włącz czytanie</p>"; 
        window.speechSynthesis.cancel(); 
    }
}
function reset(){
    location.reload()
    dzwiekprzycisku() 
}

function powrot(){
    window.location.href = 'index.html';
    dzwiekprzycisku()
}
var liczby = [1, 2, 3, 4, 5, 6];
var actualplayer = 0;

var actualpositionp1 = 0;
var actualpositionp2 = 0;
var actualpositionp3 = 0;
var actualpositionp4 = 0;
var actualpositionp5 = 0;
var liczbaokrazenp1=0;
var liczbaokrazenp2=0;
var liczbaokrazenp3=0;
var liczbaokrazenp4=0;
var liczbaokrazenp5=0;
var pomocnicze1
var pomocnicze2

var klasa1 = liczbaokrazenp1+1;
var klasa2 = liczbaokrazenp2+1;
var klasa3 = liczbaokrazenp3+1;
var klasa4 = liczbaokrazenp4+1;
var klasa5 = liczbaokrazenp5+1;
function losujtablice() {
        var wylosowanaTablica = tab1[Math.floor(Math.random() * tab1.length)];
        pomocnicze1 = wylosowanaTablica;
        console.log("Wylosowana tablica: " + pomocnicze1);
        return wylosowanaTablica;
}
function losujpytanie(){
    var wylosowanapytanie = tab2[Math.floor(Math.random() * tab2.length)];
    pomocnicze2 = wylosowanapytanie
    console.log("Wylosowane pytanie: " + pomocnicze2);
    return wylosowanapytanie;
}
var graRozpoczeta = false;

var okrazonka = "Okrążenia:<br>" +
                "Czerwony: " + klasa1 + "<br>" +
                "Zielony: " + klasa2 + "<br>" +
                "Żółty: " + klasa3 + "<br>" +
                "Niebieski: " + klasa4 + "<br>" +
                "Brązowy: " + klasa5;
function zacznijrozgrywke(){
    dzwiekprzycisku()
    document.getElementById("pole0").style = "background-image: url(P1.png)";
    document.getElementById("pole0").style = "background-image: url(P2.png)";
    document.getElementById("pole0").style = "background-image: url(P3.png)";
    document.getElementById("pole0").style = "background-image: url(P4.png)";
    document.getElementById("pole0").style = "background-image: url(P5.png)";
    document.querySelector(".okrazenia").innerHTML = okrazonka
    document.getElementById("start").disabled = true;
    graRozpoczeta = true;
}
gracz1 = "czerwony";gracz2="zielony";gracz3="żółty";gracz4="niebieski";gracz5="brązowy";
var tab1 = [1,2,3,4,5];
var tab2 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
var wylosowanatablica;
var wylosowanepytanie;
var p1 = 1
actualpositionp1++
actualpositionp2++
actualpositionp3++
actualpositionp4++
actualpositionp5++
var wczesniejszezdarzenie1 = false; 
var wczesniejszezdarzenie2 = false; 
var wczesniejszezdarzenie3 = false; 
var wczesniejszezdarzenie4 = false; 
var wczesniejszezdarzenie5 = false; 
function losuj() {
    var wylosowanatablica = losujtablice();
    var wylosowanepytanie = losujpytanie();
    var wylosowaneZdarzenie = zdarzenia[Math.floor(Math.random() * zdarzenia.length)];
    var przesuniecie = przesuniecia[wylosowaneZdarzenie];
    actualplayer = actualplayer + 1;
    dzwiekprzycisku();

    document.getElementById("losowanie").disabled = true;
    if (actualplayer > 5) {
        actualplayer = 1;
    }
    if (!graRozpoczeta) {
        return;
    }

    var kosteczka1 = liczby[Math.floor(Math.random() * liczby.length)];

    switch (kosteczka1) {
        case 1:
            document.querySelector(".kostka1").style = "background-image: url(jeden.jpg)";
            break;
        case 2:
            document.querySelector(".kostka1").style = "background-image: url(dwa.jpg)";
            break;
        case 3:
            document.querySelector(".kostka1").style = "background-image: url(trzy.jpg)";
            break;
        case 4:
            document.querySelector(".kostka1").style = "background-image: url(cztery.jpg)";
            break;
        case 5:
            document.querySelector(".kostka1").style = "background-image: url(pięć.jpg)";
            break;
        case 6:
            document.querySelector(".kostka1").style = "background-image: url(sześć.jpg)";
            break;
    }

    if (actualplayer == 1) {
        var i = 0;
        var aktualnapozycjaplusdwa1 = 2
        var wylosowanaTablicaPytan = eval('pytania' + wylosowanatablica);
        var wylosowanePytanie = wylosowanaTablicaPytan[wylosowanepytanie];
        if (odpowiedzbledna1) {
            actualpositionp1++;
            odpowiedzbledna1 = false;
        }
        actualpositionp1--;
        if(wczesniejszezdarzenie1){
            var poprzedniePole = document.getElementById("pole" + (actualpositionp1));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P1.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            actualpositionp1 = actualpositionp1 + aktualnapozycjaplusdwa1
            wczesniejszezdarzenie1 = false
            document.getElementById("pole" + actualpositionp1).style.backgroundImage = "url(P" + actualplayer + ".png)";
        }
        function chodzeniep1() {
            dzwiekchodzenia();
            var poprzedniePole = document.getElementById("pole" + (actualpositionp1 - 1));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P1.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            actualpositionp1++
            console.log("pozycja p1: " + actualpositionp1);
            if (i < kosteczka1) {
                var poprzedniePole = document.getElementById("pole" + (actualpositionp1 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P1.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                if (p1 == 1) {
                    actualpositionp1++;
                    p1--;
                }
                i++;
                if (actualpositionp1 > 23) {
                    actualpositionp1 = 0;
                    var procentpoprawnychodpowiedzip1 = (sumapoprawnychodpowiedzip1 / sumaodpowiedzip1) * 100;
                        if (procentpoprawnychodpowiedzip1 >= 50) {
                            liczbaokrazenp1++;
                            alert("Udało ci się zaliczyć klase. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip1 + " %.")
                            if(liczbaokrazenp1==5){
                                window.location.href = 'wygrany1.html';
                            }
                            klasa1 = liczbaokrazenp1 + 1;
                        }
                        else if(sumaodpowiedzip1 == 0){
                            liczbaokrazenp1++;
                            alert("Suma odpowiedzi wynosi 0. Wobec tego udało ci się zaliczyć klase :D.")
                            if(liczbaokrazenp1==5){
                                window.location.href = 'wygrany1.html';
                            }
                            klasa1 = liczbaokrazenp1 + 1;
                        }
                        else {
                            alert("niestety nie udało ci się zaliczyć klasy. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip1 + "%.")
                        }
                        okrazonka = "Okrążenia:<br>"  +
                        "Czerwony: " + klasa1 + "<br>" +
                        "Zielony: " + klasa2 + "<br>" +
                        "Żółty: " + klasa3 + "<br>" +
                        "Niebieski: " + klasa4 + "<br>" +
                        "Brązowy: " + klasa5;
        
                    document.querySelector(".okrazenia").innerHTML = okrazonka;
                    sumaodpowiedzip1 = 0;
                    sumapoprawnychodpowiedzip1 = 0;
                }
                
                setTimeout(chodzeniep1, 500);
                document.getElementById("pole" + actualpositionp1).style.backgroundImage = "url(P" + actualplayer + ".png)";
            } else {
                if (actualpositionp1 == 7 || actualpositionp1 == 13 || actualpositionp1 == 16 || actualpositionp1 == 19) {
                    document.querySelector(".pytania").innerHTML = wylosowaneZdarzenie + "<br>";
                    var starepole = document.getElementById("pole" + (actualpositionp1 - 1));
                    if (starepole && starepole.style.backgroundImage.includes("P1.png")) {
                        starepole.style.backgroundImage = "none";
                    }
                    if (przesuniecie > 0) {
                        var j = 0;
                        var interval = setInterval(function () {
                            if (j < przesuniecie) {
                                krokwprzod();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    } else {
                        wczesniejszezdarzenie1 = true; 
                        var j = 0;
                        actualpositionp1 -= 2; 
                        var interval = setInterval(function () {
                            if (j < Math.abs(przesuniecie)) {
                                krokwtyl();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                        
                    
                    }
                }
                else {
                    if(actualpositionp1==1){
                        document.querySelector(".pytania").innerHTML = "Jesteś na starcie. Jest to pole wolne od pytań :D."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else if(actualpositionp1 == 22 || actualpositionp1 == 23 || actualpositionp1 == 24){
                        document.querySelector(".pytania").innerHTML = "Już czerwiec! Oceny wystawione."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else{
                        document.querySelector(".pytania").innerHTML = wylosowanePytanie + "<br>";
                    
                        function czytamy() {
                            var pytanko = new SpeechSynthesisUtterance(wylosowanePytanie);
                            window.speechSynthesis.speak(pytanko);
                        }
            
                        if (czytanieWlaczone) {
                            czytamy();
                        }
                    }
                }
            }
        }
        function krokwprzod() {
            var starepole = document.getElementById("pole" + (actualpositionp1 - 1));
            if (starepole && starepole.style.backgroundImage.includes("P1.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp1).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp1 = actualpositionp1 + 1;
            console.log("pozycja p1: " + actualpositionp1);
        }
    
        function krokwtyl() {
            var starepole = document.getElementById("pole" + (actualpositionp1 + 1));
            if (starepole && starepole.style.backgroundImage.includes("P1.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp1).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp1--
            aktualnapozycjaplusdwa1 = actualpositionp1 + 2;
            console.log("pozycja p1: " + aktualnapozycjaplusdwa1);
        }
        setTimeout(chodzeniep1, 500);
        document.querySelector(".gracz").innerHTML = "<p>Aktualny gracz:    " + gracz1 +"</p>";
        document.getElementById("pole" + actualpositionp1).style = "background-image: url(P" + actualplayer + ".png)";
        p1++;
    }
    
    if (actualplayer == 2) {
        var i = 0;
        var aktualnapozycjaplusdwa2 = 2
        var wylosowanaTablicaPytan = eval('pytania' + wylosowanatablica);
        var wylosowanePytanie = wylosowanaTablicaPytan[wylosowanepytanie];
        
        if(odpowiedzbledna2){
            actualpositionp2++;
            odpowiedzbledna2 = false
        }
        actualpositionp2--;
        if(wczesniejszezdarzenie2){
            var poprzedniePole = document.getElementById("pole" + (actualpositionp2));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P2.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            actualpositionp2 = actualpositionp2 + aktualnapozycjaplusdwa2
            wczesniejszezdarzenie2 = false
            document.getElementById("pole" + actualpositionp2).style.backgroundImage = "url(P" + actualplayer + ".png)";
        }
        function chodzeniep2() {
            dzwiekchodzenia();
            var poprzedniePole = document.getElementById("pole" + (actualpositionp2 - 1));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P2.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            
            actualpositionp2++;
            console.log("pozycja p2: " + actualpositionp2);
            if (i < kosteczka1) {
                var poprzedniePole = document.getElementById("pole" + (actualpositionp2 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P2.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                if (p1 == 1) {
                    actualpositionp2++;
                    p1--;
                }
                i++;
                if (actualpositionp2 > 23) {
                    actualpositionp2 = 0;
                    var procentpoprawnychodpowiedzip2 = (sumapoprawnychodpowiedzip2 / sumaodpowiedzip2) * 100;
                        if (procentpoprawnychodpowiedzip2 >= 50) {
                            liczbaokrazenp2++;
                            alert("udało ci się zaliczyć klase. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip2 + " %.")
                            if(liczbaokrazenp2==5){
                                window.location.href = 'wygrany2.html';
                            }
                            klasa2 = liczbaokrazenp2 + 1;
                        }
                        else if(sumaodpowiedzip2 == 0){
                            liczbaokrazenp2++;
                            alert("Suma odpowiedzi wynosi 0. Wobec tego udało ci się zaliczyć klase :D.")
                            if(liczbaokrazenp2==5){
                                window.location.href = 'wygrany2.html';
                            }
                            klasa2 = liczbaokrazenp2 + 1;
                        }
                        else {
                            alert("niestety nie udało ci się zaliczyć klasy. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip2 + "%.")
                        }
                        okrazonka = "Okrążenia:<br>" +
                        "Czerwony: " + klasa1 + "<br>" +
                        "Zielony: " + klasa2 + "<br>" +
                        "Żółty: " + klasa3 + "<br>" +
                        "Niebieski: " + klasa4 + "<br>" +
                        "Brązowy: " + klasa5;
        
                    document.querySelector(".okrazenia").innerHTML = okrazonka;
                    
                    sumaodpowiedzip2 = 0;
                    sumapoprawnychodpowiedzip2 = 0;
                }
                document.getElementById("pole" + actualpositionp2).style.backgroundImage = "url(P" + actualplayer + ".png)";
                setTimeout(chodzeniep2, 500);
            } else {
                if (actualpositionp2 == 7 || actualpositionp2 == 13 || actualpositionp2 == 16 || actualpositionp2 == 19) { 
                    document.querySelector(".pytania").innerHTML = wylosowaneZdarzenie + "<br>";
                    var starepole = document.getElementById("pole" + (actualpositionp2 - 1));
                    if (starepole && starepole.style.backgroundImage.includes("P2.png")) {
                        starepole.style.backgroundImage = "none";
                    }
                    if (przesuniecie > 0) {
                        var j = 0;
                        var interval = setInterval(function () {
                            if (j < przesuniecie) {
                                krokwprzod();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    } else {
                        var j = 0;
                        wczesniejszezdarzenie2 = true;
                        actualpositionp2 = actualpositionp2 - 2;
                        var interval = setInterval(function () {
                            if (j < Math.abs(przesuniecie)) {
                                krokwtyl();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    }
                } else {
                    if(actualpositionp2==1){
                        document.querySelector(".pytania").innerHTML = "Jesteś na starcie. Jest to pole wolne od pytań :D."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else if(actualpositionp2 == 22 || actualpositionp2 == 23 || actualpositionp2 == 24){
                        document.querySelector(".pytania").innerHTML = "Już czerwiec! Oceny wystawione."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else{
                        document.querySelector(".pytania").innerHTML = wylosowanePytanie + "<br>";
                        function czytamy() {
                            var pytanko = new SpeechSynthesisUtterance(wylosowanePytanie);
                            window.speechSynthesis.speak(pytanko);
                        }
            
                        if (czytanieWlaczone) {
                            czytamy();
                        }
                    }
                }
            }
        }
        
        function krokwprzod() {
            var starepole = document.getElementById("pole" + (actualpositionp2 - 1));
            if (starepole && starepole.style.backgroundImage.includes("P2.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp2).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp2 = actualpositionp2 + 1;
            console.log("pozycja p2: " + actualpositionp2);
        }
        
        function krokwtyl() {
            var starepole = document.getElementById("pole" + (actualpositionp2 + 1));
            if (starepole && starepole.style.backgroundImage.includes("P2.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp2).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp2 = actualpositionp2 - 1;
            aktualnapozycjaplusdwa2 = actualpositionp2 + 2;
            console.log("pozycja p2: " + aktualnapozycjaplusdwa2);
        }
        setTimeout(chodzeniep2, 500);
        document.querySelector(".gracz").innerHTML = "<p>Aktualny gracz:    " + gracz2 +"</p>";
        document.getElementById("pole" + actualpositionp2).style = "background-image: url(P" + actualplayer + ".png)";
        p1++;
    }  
    if (actualplayer == 3) {
        var i = 0;
        var aktualnapozycjaplusdwa3 = 2
        var wylosowanaTablicaPytan = eval('pytania' + wylosowanatablica);
        var wylosowanePytanie = wylosowanaTablicaPytan[wylosowanepytanie];
        if(odpowiedzbledna3){
            actualpositionp3++;
            odpowiedzbledna3 = false
        }
        actualpositionp3--;
        if(wczesniejszezdarzenie3){
            var poprzedniePole = document.getElementById("pole" + (actualpositionp3));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P3.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            actualpositionp3 = actualpositionp3 + aktualnapozycjaplusdwa3
            wczesniejszezdarzenie3 = false
            document.getElementById("pole" + actualpositionp3).style.backgroundImage = "url(P" + actualplayer + ".png)";
        }
        function chodzeniep3() {
            dzwiekchodzenia();
            var poprzedniePole = document.getElementById("pole" + (actualpositionp3 - 1));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P3.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            actualpositionp3++;
            console.log("pozycja p3: " + actualpositionp3);
            if (i < kosteczka1) {
                var poprzedniePole = document.getElementById("pole" + (actualpositionp3 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P3.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                if (p1 == 1) {
                    actualpositionp3++;
                    p1--;
                }
                i++;
                if (actualpositionp3 > 23) {
                    actualpositionp3 = 0;
                    var procentpoprawnychodpowiedzip3 = (sumapoprawnychodpowiedzip3 / sumaodpowiedzip3) * 100;
                        if (procentpoprawnychodpowiedzip3 >= 50) {
                            liczbaokrazenp3++;
                            alert("udało ci się zaliczyć klase. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip3 + " %.")
                            if(liczbaokrazenp3==5){
                                window.location.href = 'wygrany3.html';
                            }
                            klasa3 = liczbaokrazenp3 + 1;
                        }
                        else if(sumaodpowiedzip3 == 0){
                            liczbaokrazenp3++;
                            alert("Suma odpowiedzi wynosi 0. Wobec tego udało ci się zaliczyć klase :D.")
                            if(liczbaokrazenp3==5){
                                window.location.href = 'wygrany3.html';
                            }
                            klasa3 = liczbaokrazenp3 + 1;
                        }
                        else {
                            alert("niestety nie udało ci się zaliczyć klasy. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip3 + "%.")
                        }
                        okrazonka = "Okrążenia:<br>" +
                        "Czerwony: " + klasa1 + "<br>" +
                        "Zielony: " + klasa2 + "<br>" +
                        "Żółty: " + klasa3 + "<br>" +
                        "Niebieski: " + klasa4 + "<br>" +
                        "Brązowy: " + klasa5;
        
                    document.querySelector(".okrazenia").innerHTML = okrazonka;
                    
                    sumaodpowiedzip3 = 0;
                    sumapoprawnychodpowiedzip3 = 0;
                }
                document.getElementById("pole" + actualpositionp3).style.backgroundImage = "url(P" + actualplayer + ".png)";
                setTimeout(chodzeniep3, 500);
            } else {
                if (actualpositionp3 == 7 || actualpositionp3 == 13 || actualpositionp3 == 16 || actualpositionp3 == 19) {
                    document.querySelector(".pytania").innerHTML = wylosowaneZdarzenie + "<br>";
                    var starepole = document.getElementById("pole" + (actualpositionp3 - 1));
                    if (starepole && starepole.style.backgroundImage.includes("P3.png")) {
                        starepole.style.backgroundImage = "none";
                    }
                    if (przesuniecie > 0) {
                        var j = 0;
                        var interval = setInterval(function () {
                            if (j < przesuniecie) {
                                krokwprzod();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    } else {
                        var j = 0;
                        wczesniejszezdarzenie3 = true;
                        actualpositionp3 = actualpositionp3 - 2;
                        var interval = setInterval(function () {
                            if (j < Math.abs(przesuniecie)) {
                                krokwtyl();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    }
                } else {
                    if(actualpositionp3==1){
                        document.querySelector(".pytania").innerHTML = "Jesteś na starcie. Jest to pole wolne od pytań :D."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else if(actualpositionp3 == 22 || actualpositionp3 == 23 || actualpositionp3 == 24){
                        document.querySelector(".pytania").innerHTML = "Już czerwiec! Oceny wystawione."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else{
                        document.querySelector(".pytania").innerHTML = wylosowanePytanie + "<br>";
                        function czytamy() {
                            var pytanko = new SpeechSynthesisUtterance(wylosowanePytanie);
                            window.speechSynthesis.speak(pytanko);
                        }
            
                        if (czytanieWlaczone) {
                            czytamy();
                        }
                    }
                }
            }
        }
    
        function krokwprzod() {
            var starepole = document.getElementById("pole" + (actualpositionp3 - 1));
            if (starepole && starepole.style.backgroundImage.includes("P3.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp3).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp3 = actualpositionp3 + 1;
            console.log("pozycja p3: " + actualpositionp3);
        }
        
        function krokwtyl() {
            var starepole = document.getElementById("pole" + (actualpositionp3 + 1));
            if (starepole && starepole.style.backgroundImage.includes("P3.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp3).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp3 = actualpositionp3 - 1;
            aktualnapozycjaplusdwa3 = actualpositionp3 + 2;
            console.log("pozycja p3: " + aktualnapozycjaplusdwa3);
        }
        setTimeout(chodzeniep3, 500);
        document.querySelector(".gracz").innerHTML = "<p>Aktualny gracz:    " + gracz3+"</p>";
        document.getElementById("pole" + actualpositionp3).style = "background-image: url(P" + actualplayer + ".png)";
        p1++;
    }
    if (actualplayer == 4) {
        var i = 0;
        var aktualnapozycjaplusdwa4 = 2
        var wylosowanaTablicaPytan = eval('pytania' + wylosowanatablica);
        var wylosowanePytanie = wylosowanaTablicaPytan[wylosowanepytanie];
        if(odpowiedzbledna4){
            actualpositionp4++;
            odpowiedzbledna4 = false
        }
        actualpositionp4--;
        if(wczesniejszezdarzenie4){
            var poprzedniePole = document.getElementById("pole" + (actualpositionp4));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P4.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            actualpositionp4 = actualpositionp4 + aktualnapozycjaplusdwa4
            wczesniejszezdarzenie4 = false
            document.getElementById("pole" + actualpositionp4).style.backgroundImage = "url(P" + actualplayer + ".png)";
        }
        function chodzeniep4() {
            dzwiekchodzenia();
            var poprzedniePole = document.getElementById("pole" + (actualpositionp4 - 1));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P4.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            
            actualpositionp4++;
            console.log("pozycja p4: " + actualpositionp4);
            if (i < kosteczka1) {
                var poprzedniePole = document.getElementById("pole" + (actualpositionp4 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P4.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                if (p1 == 1) {
                    actualpositionp4++;
                    p1--;
                }
                i++;
                if (actualpositionp4 > 23) {
                    actualpositionp4 = 0;
                    var procentpoprawnychodpowiedzip4 = (sumapoprawnychodpowiedzip4 / sumaodpowiedzip4) * 100;
                        if (procentpoprawnychodpowiedzip4 >= 50) {
                            liczbaokrazenp4++;
                            alert("udało ci się zaliczyć klase. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip4 + " %.")
                            if(liczbaokrazenp4==5){
                                window.location.href = 'wygrany4.html';
                            }
                            klasa4 = liczbaokrazenp4 + 1;
                        }
                        else if(sumaodpowiedzip4 == 0){
                            liczbaokrazenp4++;
                            alert("Suma odpowiedzi wynosi 0. Wobec tego udało ci się zaliczyć klase :D.")
                            if(liczbaokrazenp4==5){
                                window.location.href = 'wygrany4.html';
                            }
                            klasa4 = liczbaokrazenp4 + 1;
                        }
                        else {
                            alert("niestety nie udało ci się zaliczyć klasy. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip4 + "%.")
                        }
                        okrazonka = "Okrążenia:<br>" +
                        "Czerwony: " + klasa1 + "<br>" +
                        "Zielony: " + klasa2 + "<br>" +
                        "Żółty: " + klasa3 + "<br>" +
                        "Niebieski: " + klasa4 + "<br>" +
                        "Brązowy: " + klasa5;
        
                    document.querySelector(".okrazenia").innerHTML = okrazonka;
                    
                    sumaodpowiedzip4 = 0;
                    sumapoprawnychodpowiedzip4 = 0;
                }
                document.getElementById("pole" + actualpositionp4).style.backgroundImage = "url(P" + actualplayer + ".png)";
                setTimeout(chodzeniep4, 500);
            } else {
                if (actualpositionp4 == 7 || actualpositionp4 == 13 || actualpositionp4 == 16 || actualpositionp4 == 19) {
                    document.querySelector(".pytania").innerHTML = wylosowaneZdarzenie + "<br>";
                    var starepole = document.getElementById("pole" + (actualpositionp4 - 1));
                    if (starepole && starepole.style.backgroundImage.includes("P4.png")) {
                        starepole.style.backgroundImage = "none";
                    }
                    if (przesuniecie > 0) {
                        var j = 0;
                        var interval = setInterval(function () {
                            if (j < przesuniecie) {
                                krokwprzod();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    } else {
                        var j = 0;
                        wczesniejszezdarzenie4 = true;
                        actualpositionp4 = actualpositionp4 - 2;
                        var interval = setInterval(function () {
                            if (j < Math.abs(przesuniecie)) {
                                krokwtyl();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    }
                } else {
                    if(actualpositionp4==1){
                        document.querySelector(".pytania").innerHTML = "Jesteś na starcie. Jest to pole wolne od pytań :D. "
                        document.getElementById("losowanie").disabled = false;
                    }
                    else if(actualpositionp4 == 22 || actualpositionp4 == 23 || actualpositionp4 == 24){
                        document.querySelector(".pytania").innerHTML = "Już czerwiec! Oceny wystawione."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else{
                        document.querySelector(".pytania").innerHTML = wylosowanePytanie + "<br>";
        
                        function czytamy() {
                            var pytanko = new SpeechSynthesisUtterance(wylosowanePytanie);
                            window.speechSynthesis.speak(pytanko);
                        }
            
                        if (czytanieWlaczone) {
                            czytamy();
                        }
                    }
                    
                }
            }
        }
        
        
        
        function krokwprzod() {
            var starepole = document.getElementById("pole" + (actualpositionp4 - 1));
            if (starepole && starepole.style.backgroundImage.includes("P4.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp4).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp4 = actualpositionp4 + 1;
            console.log("pozycja p4: " + actualpositionp4);
        }
        
        function krokwtyl() {
            var starepole = document.getElementById("pole" + (actualpositionp4 + 1));
            if (starepole && starepole.style.backgroundImage.includes("P4.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp4).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp4 = actualpositionp4 - 1;
            aktualnapozycjaplusdwa4 = actualpositionp4 + 2;
            console.log("pozycja p4: " + aktualnapozycjaplusdwa4);
        }
        setTimeout(chodzeniep4, 500);
        document.querySelector(".gracz").innerHTML = "<p>Aktualny gracz:    " + gracz4+"</p>";
        document.getElementById("pole" + actualpositionp4).style = "background-image: url(P" + actualplayer + ".png)";
        p1++;
    }
    if (actualplayer == 5) {
        var i = 0;
        var aktualnapozycjaplusdwa5 = 2
        var wylosowanaTablicaPytan = eval('pytania' + wylosowanatablica);
        var wylosowanePytanie = wylosowanaTablicaPytan[wylosowanepytanie];
        if(odpowiedzbledna5){
            actualpositionp5++;
            odpowiedzbledna5 = false
        }
        actualpositionp5--;
        if(wczesniejszezdarzenie5){
            var poprzedniePole = document.getElementById("pole" + (actualpositionp5));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P5.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            actualpositionp5 = actualpositionp5 + aktualnapozycjaplusdwa5
            wczesniejszezdarzenie5 = false
            document.getElementById("pole" + actualpositionp5).style.backgroundImage = "url(P" + actualplayer + ".png)";
        }
        function chodzeniep5() {
            dzwiekchodzenia();
            var poprzedniePole = document.getElementById("pole" + (actualpositionp5 - 1));
            if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P5.png")) {
                poprzedniePole.style.backgroundImage = "none";
            }
            actualpositionp5++;
            console.log("pozycja p5: " + actualpositionp5);
            if (i < kosteczka1) {
                var poprzedniePole = document.getElementById("pole" + (actualpositionp5 - 1));
                if (poprzedniePole && poprzedniePole.style.backgroundImage.includes("P5.png")) {
                    poprzedniePole.style.backgroundImage = "none";
                }
                if (p1 == 1) {
                    actualpositionp5++;
                    p1--;
                }
                i++;
                if (actualpositionp5 > 23) {
                    actualpositionp5 = 0;
                    var procentpoprawnychodpowiedzip5 = (sumapoprawnychodpowiedzip5 / sumaodpowiedzip5) * 100;
                        if (procentpoprawnychodpowiedzip5 >= 50) {
                            liczbaokrazenp5++;
                            alert("udało ci się zaliczyć klase. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip5 + " %.")
                            if(liczbaokrazenp5==5){
                                window.location.href = 'wygrany5.html';
                            }
                            klasa5 = liczbaokrazenp5 + 1;
                        }
                        else if(sumaodpowiedzip5 == 0){
                            liczbaokrazenp5++;
                            alert("Suma odpowiedzi wynosi 0. Wobec tego udało ci się zaliczyć klase :D.")
                            if(liczbaokrazenp5==5){
                                window.location.href = 'wygrany5.html';
                            }
                            klasa5 = liczbaokrazenp5 + 1;
                        }
                        else {
                            alert("niestety nie udało ci się zaliczyć klasy. Twój procent poprawnych odpowiedzi wyniósł " + procentpoprawnychodpowiedzip5 + "%.")
                        }
                        okrazonka = "Okrążenia:<br>" +
                        "Czerwony: " + klasa1 + "<br>" +
                        "Zielony: " + klasa2 + "<br>" +
                        "Żółty: " + klasa3 + "<br>" +
                        "Niebieski: " + klasa4 + "<br>" +
                        "Brązowy: " + klasa5;
        
                    document.querySelector(".okrazenia").innerHTML = okrazonka;
                    
                    sumaodpowiedzip5 = 0;
                    sumapoprawnychodpowiedzip5 = 0;
                }
                document.getElementById("pole" + actualpositionp5).style.backgroundImage = "url(P" + actualplayer + ".png)";
                setTimeout(chodzeniep5, 500);
            } else {
                if (actualpositionp5 == 7 || actualpositionp5 == 13 || actualpositionp5 == 16 || actualpositionp5 == 19) {
                    document.querySelector(".pytania").innerHTML = wylosowaneZdarzenie + "<br>";
                    var starepole = document.getElementById("pole" + (actualpositionp5 - 1));
                    if (starepole && starepole.style.backgroundImage.includes("P5.png")) {
                        starepole.style.backgroundImage = "none";
                    }
                    if (przesuniecie > 0) {
                        var j = 0;
                        var interval = setInterval(function () {
                            if (j < przesuniecie) {
                                krokwprzod();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    } else {
                        var j = 0;
                        wczesniejszezdarzenie5 = true;
                        actualpositionp5 = actualpositionp5 - 2;
                        var interval = setInterval(function () {
                            if (j < Math.abs(przesuniecie)) {
                                krokwtyl();
                                j++;
                            } else {
                                clearInterval(interval);
                                document.getElementById("losowanie").disabled = false;
                            }
                        }, 400);
                    }
                } else {
                    if(actualpositionp5==1){
                        document.querySelector(".pytania").innerHTML = "Jesteś na starcie. Jest to pole wolne od pytań :D."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else if(actualpositionp5 == 22 || actualpositionp5 == 23 || actualpositionp5 == 24){
                        document.querySelector(".pytania").innerHTML = "Już czerwiec! Oceny wystawione."
                        document.getElementById("losowanie").disabled = false;
                    }
                    else{
                        document.querySelector(".pytania").innerHTML = wylosowanePytanie + "<br>";
                        function czytamy() {
                            var pytanko = new SpeechSynthesisUtterance(wylosowanePytanie);
                            window.speechSynthesis.speak(pytanko);
                        }
            
                        if (czytanieWlaczone) {
                            czytamy();
                        }
                    }
                }
            }
        }
        
        function krokwprzod() {
            var starepole = document.getElementById("pole" + (actualpositionp5 - 1));
            if (starepole && starepole.style.backgroundImage.includes("P5.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp5).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp5 = actualpositionp5 + 1;
            console.log("pozycja p5: " + actualpositionp5);
        }
        
        function krokwtyl() {
            var starepole = document.getElementById("pole" + (actualpositionp5 + 1));
            if (starepole && starepole.style.backgroundImage.includes("P5.png")) {
                starepole.style.backgroundImage = "none";
            }
            document.getElementById("pole" + actualpositionp5).style.backgroundImage = "url(P" + actualplayer + ".png)";
            actualpositionp5 = actualpositionp5 - 1;
            aktualnapozycjaplusdwa5 = actualpositionp5 + 2;
            console.log("pozycja p5: " + aktualnapozycjaplusdwa5);
        }
        setTimeout(chodzeniep5, 500);
        document.querySelector(".gracz").innerHTML = "<p>Aktualny gracz:    " + gracz5 + "</p>";
        document.getElementById("pole" + actualpositionp5).style = "background-image: url(P" + actualplayer + ".png)";
        p1++;
    }
}