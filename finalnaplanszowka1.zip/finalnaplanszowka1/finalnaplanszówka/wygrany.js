var zwyciestwo = new Audio("medieval-fanfare-6826.mp3");
var klikniecie = new Audio('840.mp3');
klikniecie.volume = 0.5;
function dzwiekprzycisku(){
    klikniecie.play();
}
zwyciestwo.volume = 0.4;
function zwyciestwo(){
    zwyciestwo.play()
}
zwyciestwo();
function wrocdogry(){
    window.location.href = 'index.html'
    dzwiekprzycisku()
}
function powrot(){
    window.location.href = 'indexik.html'
    dzwiekprzycisku()
}