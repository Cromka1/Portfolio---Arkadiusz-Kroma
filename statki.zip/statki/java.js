const tab = [1, 2, 3, 4, 5, 6, 7];
const tab1 = ["A", "B", "C", "D", "E", "F", "G"];
var a1, a2, b1, b2, c1, c2;
do {
    a1 = tab[Math.floor(Math.random() * tab.length)];
    a2 = tab1[Math.floor(Math.random() * tab1.length)];
    const pion = Math.random() < 0.5;
    if (pion) {
        b1 = a1 + 1;
        b2 = a2;
        c1 = b1 + 1;
        c2 = a2;
    } else {
        b1 = a1;
        b2 = tab1.indexOf(a2) + 1 < tab1.length ? tab1[tab1.indexOf(a2) + 1]:a2;
        c1 = a1;
        c2 = tab1.indexOf(b2) + 1 < tab1.length ? tab1[tab1.indexOf(b2) + 1]:b2;
    }
} while (a1 > 7 || b1 > 7 || c1 > 7 || a2>"E"||b2>"F"||c2>"G");
console.log(a1,a2,b1,b2,c1,c2)
loka1=1
loka2=1
lokb1=1
lokb2=1
lokc1=1
lokc2=1
var ls=0
var ta=[]
var t=[]
function statek(){
        var y=prompt("podaj współrzędną od A do G")
        var x=prompt("podaj współrzędną od 1 do 7")
        console.log()
        if(y==a2 && x==a1){
            loka1=0
            loka2=0
            ls=ls+1
            document.querySelector(".apla" + y + x).style="background-image: url(x.jfif); background-size:cover;"
            t.push(y+x.toString()+'<br>')
            document.querySelector(".adblock6").innerHTML = t 
        }
        else if(y==b2 && x==b1){
            lokb1=0
            lokb2=0
            ls=ls+1
            document.querySelector(".apla" + y + x).style="background-image: url(x.jfif); background-size:cover;"
            t.push(y+x.toString()+'<br>')
            document.querySelector(".adblock6").innerHTML = t
            }
        else if(y==c2 && x==c1){
            lokc1=0
            lokc2=0
            ls=ls+1
            document.querySelector(".apla" + y + x).style="background-image: url(x.jfif); background-size:cover;"
            t.push(y+x.toString()+'<br>')
            document.querySelector(".adblock6").innerHTML = t
            }
        else{
            document.querySelector(".apla" + y + x).style="background-image: url(kółko.jfif); background-size:cover;"
            ls=ls+1
            ta.push(y+x.toString()+'<br>')
            document.querySelector(".adblock2").innerHTML = ta 
            
            
        }
    if(loka1==0 && loka2==0 &&lokb1==0 && lokb2==0 &&lokc1==0 && lokc2==0 ){
        document.write("trafiony zatopiony! udało ci się zestrzelić trzymasztowiec po " + ls + " strzałach co daje " + 300/ls + "% skuteczności!")   
    }
    }